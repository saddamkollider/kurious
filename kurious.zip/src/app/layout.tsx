import KuriousNavbar from '@/components/navigation/Navbar'
import './globals.css'
import { Inter } from 'next/font/google'
import KuriousFooter from '@/components/navigation/Footer'
import type { Metadata } from 'next'

const inter = Inter({ subsets: ['latin'] })


 
export const metadata: Metadata = {
  title: "The Kurious",
  description: `We are a creative collective agency of great content expertise driven by a desire to make and tell great stories.
  The Kurious is our creative hub and production studio, built for established and emerging TV, film and documentary makers, animators, designers and story-makers and home to a range of freelance technicians based in Sheffield.`,

}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <KuriousNavbar />
        {children}
        <KuriousFooter />
        </body>
    </html>
  )
}
