'use client'
import React from 'react';


interface SpaceProps {
  title: string;
  description: string;
  imageSrc: string;
}

const Space: React.FC<SpaceProps> = ({ title, description, imageSrc }) => {
  return (
    <div className="relative group">
      <img className="w-full h-auto" src={imageSrc} alt={title} />
      <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-80 transition-opacity duration-300">
        <div className="flex items-center justify-center h-full">
          <div className="text-white text-center">
            <h3 className="text-2xl font-bold mb-2">{title}</h3>
            <p>{description}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const spaces: SpaceProps[] = [
    {
      title: 'Sound Suite',
      description:
        'Industry standard Neumann, Schoeps and Sennheiser microphones in a fully sound attenuated booth complete with playback monitoring and EdiCue / EdiPrompt software for precise ADR and foley recording.',
      imageSrc: '/pictures/editing.png',
    },
    {
        title: 'Edit Suite',
        description:
          'Sound attenuated suite for professional editing and grading for commercials, shNotes:orts, documentaries and feature films; projection at 4K on a 150” screen with 5.1 surround sound and client seating for up to 20 people.',
        imageSrc: '/pictures/editing.png',
      },
      {
        title: 'Production Space',
        description:
        'Six fully serviced offices ranging in size between 15 and 18 square metres. Benefit from a pool of on-site creative professionals of varying skills all calling Kurious their home.',  
        imageSrc: '/pictures/editing.png',
      },
      {
        title: 'Photography Space',
        description:
          'With access to a creative hub in the centre of Sheffield, our studio spaces are designed to accommodate and facilitate established and emerging photographers, modelling agencies, creative content creators, designers, and creative tech.',
          imageSrc: '/pictures/editing.png',
      },
      {
        title: 'Event Space (Use Event Brochure/packages)',
        description:
          'The Kurious facilities include a 900 sq ft event space along with informal spaces providing opportunities for rehearsals, events of all types, green screen and visiting productions.',
          imageSrc: '/pictures/editing.png',
      },
    // Add other space objects
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
      {spaces.map((space, index) => (
        <Space key={index} {...space} />
      ))}
    </div>
  );
};

export default App;
