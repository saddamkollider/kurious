'use client'

import React, { FC, useState } from "react";

import Link from "next/link";
import { BiLogoInstagram, BiLogoTiktok } from "react-icons/bi";
import { FaFacebookF } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FiPhoneCall } from "react-icons/fi";

interface GridItemProps {
  imageUrl: string;
  text: string;
  texts: string;
}

const GridItem: FC<GridItemProps> = ({ imageUrl, text, texts}) => (
<div>
  <div className="relative group">
      <a>
    <div
      className="bg-cover bg-center h-72 md:h-80 lg:h-[60vh] bg-no-repeat mt-5 md:mt-4 lg:mt-3"
      style={{ backgroundImage: `url(${imageUrl})` }} 
    >
      <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-50 transition duration-300"></div>
    </div>
    <div className="absolute bottom-3 ml-4 w-full top-5 mt-2 lg:mt-2 opacity-0 group-hover:opacity-100 transition duration-300">
      <p className="text-white text-lg md:text-xl lg:text-4xl font-semibold uppercase">{text}</p>
      <p className="text-primary -mt-2 pt-1 lg:mt-1 text-sm md:text-xl lg:text-sm font-semibold uppercase">{texts}</p>
          </div>
    </a>
  </div>
  </div>
 
);

interface KuriousstaffProps {}

const Creators: FC<KuriousstaffProps> = () => {
  const [search, setSearch] = useState('');

  const gridItems = [

    {    
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/jettprofile.png",
      text:"Jett",
      texts:"Creative Marketing Manager",
      url:"",
      },

      {
        imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/dan2.jpg",
        text:"Dan",
        texts:"Operations Manager",
        url:"",
      },
      {
        imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/olaprofilepic.png",
        text:"Ola",
        texts:"Web Developer",
        url:"",
       },
      {
        imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/jakeprofilepic.png",
        text:"Jake",
        texts:"Fullstack web developer",
        
      },
      {
        imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/moprofile.png",
        text:"MO",
        texts:"platform Development Manager",
        
    },
    {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/Broniaprofilepic.png",
      text:"Bronia",
      texts:"Marketing Assistant",
      
  },
  {
    imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/Emprofilepic.png",
    text:"Em",
    texts:"Sound Tech/Studio Engineer",
    
},
//    
  
  ];
 /**the filter grid items based on the search query */

  const filteredGridItems = gridItems.filter((item) =>
    item.text.toLowerCase().includes(search.toLowerCase())||
    item.texts.toLowerCase().includes(search.toLowerCase())
  );


  return (
    <main className="px-10">
     
<div className="pt-10">

          <input
          className="max-w"
            type="text"
            placeholder="Search "
            value={search}
            onChange={(e) =>{
              setSearch(e.target.value);
            }
          }                                
          /> 


    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 lg:mt-5">
      

                            {gridItems.map((item) => {
                                        if (item.texts.toLowerCase().includes(search.toLowerCase())||
                                            item.text.toLowerCase().includes(search.toLowerCase())){
                                          return (
                                            <GridItem
                                              key={item.text}
                                              imageUrl={item.imageUrl}
                                              text={item.text}
                                              texts={item.texts}
                                             
                                            />
                                           
                                          );
                                        }
                                        return null; // Hide non-matching items
                                      })}
                                      
            </div>
            
    </div>
    
    <div className="w-full mt-5 ">
        <ul className="flex mb-2 md:justify-end md:gap-4 justify-between text-2xl items-center ">
          <li>
          <Link href='https://www.instagram.com/thekurious_/'>
            <BiLogoInstagram />
            </Link>
          </li>
          <li>
          <Link href='https://www.facebook.com/people/The-Kurious/100079157044792/'>
            <FaFacebookF />
            </Link>
          </li>
          <li>
          <Link href='https://twitter.com/thekurious_'>
            <FaXTwitter />
            </Link>
          </li>
          <li>
          <Link href='https://www.tiktok.com/@thekurious_'>
            <BiLogoTiktok />
            </Link>
          </li>
          <li>
          <Link href='tel:01143123659'>
            <FiPhoneCall />
            </Link>
          </li>
          <Link href="#">
            <li className="px-2 py-1 text-sm md:text-lg bg-primary rounded-lg shadow-md ">
              BOOK NOW
            </li>
          </Link>
        </ul>
      </div>

</main>
  );
};

export default Creators;
