"use client"
import MainCard from "@/components/ui/MainCard";
import type { FC } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import {FaPhoneVolume} from 'react-icons/fa6';
import {IoMdMail} from 'react-icons/io';
import {FaLocationDot} from 'react-icons/fa6';
import {GiPostOffice} from 'react-icons/gi';
import React from 'react'
import SocialLink from "@/components/ui/SociMediaIcon/page";
import ContactForm from "@/components/ui/ContactForm";

interface KuriousProps {}

const Kurious: FC<KuriousProps> = () => {
  const handleSubmit = (data: any) => {
    // Handle form submission here, e.g., send data to server
    console.log(data);
  };



  return (
    <main className="px-10">

         <MainCard>
         <img
          className=" object-cover h-full w-full"
          src="/pictures/space4.png"
          alt="contact us"
        />     
            </MainCard>
            <SocialLink/>
    
             <div className='mt-5 mx-auto max-w-5xl'> 
<div className=' mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 md:h-auto lg:h-auto bg-white md:m-5 lg:m-5'>
  <div className=''>
    <div className='flex flex-col justify-between h-full'>
      <div className='bg-white'>
      <FaPhoneVolume className=' text-3xl font-bold'/> 
      <div><p> Phone Number</p></div>
      <div><a href='tel:01143123659'>+44 (0) 1143123659</a></div>
      </div>
      <div className='bg-white '>
      <div className='bg-white'>
        <IoMdMail className='text-3xl '/>
    <div><p> Email Address</p></div> 
    <div><a href='mailto:enquiries@the-kurious.com'>enquiries@the-kurious.com</a></div>
    </div>        
        </div>
      <div className='bg-white'>
      <div className='bg-white'>
        <GiPostOffice className = 'text-3xl'/>
        <p>Office Opening Hours:</p>
        <p>Monday – Friday 8 am – 6 pm </p>
      </div>     
      </div>
      <div className='bg-white'>
        <div className='bg-white'>
        <FaLocationDot className='text-3xl'/>
        <p> Location</p>
      <p> Level 1,Castle House,</p> 
      <p> Sheffield S3 8LS,United Kingdom</p>
      </div>
      </div>
    </div>
  </div>
  <div className=''>
  <div>
    <ContactForm onSubmit={handleSubmit}/>
  
    {/* <iframe
      src="https://www.cognitoforms.com/f/TBvlivnYu0qXj9F9C55Oqg/128"
      style={{ border: '0', width: '100%' }}

      height="620"
      title="Cognito Form"
    ></iframe> */}
  </div>
</div>

</div>
</div>


            
            
    
    </main>
  );
};

export default Kurious;


