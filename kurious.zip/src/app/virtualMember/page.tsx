'use client'
import MainCard from "@/components/ui/MainCard";
import React, { FC, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { BiLogoInstagram, BiLogoTiktok } from "react-icons/bi";
import { FaFacebookF } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FiPhoneCall } from "react-icons/fi";

interface GridItemProps {
  imageUrl: string;
  text: string;
  texts: string;
  url:string;
  aboutMe:string;
  textbook:string;
}

const GridItem: FC<GridItemProps> = ({ imageUrl, text, texts, url, aboutMe, textbook }) => (
  <Link href={url}>
  <div className="relative group">
      <a>
    <div
      className="bg-cover bg-center grayscale  h-72 md:h-80 lg:h-[60vh] bg-no-repeat mt-5 md:mt-4 lg:mt-3"
      style={{ backgroundImage: `url(${imageUrl})` }} 
    >
      <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-40 transition duration-300"></div>
    </div>
    <div className="absolute bottom-3 ml-4 w-full top-0 mt-2 lg:mt-2 opacity-0 group-hover:opacity-100 transition duration-300">
      <p className="text-white text-lg md:text-xl lg:text-4xl font-semibold uppercase">{text}</p>
      <p className="text-primary -mt-2 pt-1 lg:mt-1 text-sm md:text-xl lg:text-sm font-semibold uppercase">{texts}</p>
      <p className=" text-justify w-[90%] pr-2 pt-3 text-white -mt-2 lg:mt-1 text-[0.5rem] md:text-xl lg:text-sm font-semibold">{aboutMe}</p>
      <p className="uppercase absolute bottom-5 right-5 text-primary  text-1xl md:text-7xl lg:mr-4 mr-3 lg:text-2xl font-bold text-right ">{textbook}</p>
          </div>
    </a>
  </div>
   </Link>
);

interface CreatorsProps {}

const Creators: FC<CreatorsProps> = () => {
  const [search, setSearch] = useState('');

  const gridItems = [

    {    
      imageUrl:"/assets/virtualmemberImages/Cassidy-Civiero-Headshot.jpeg",
      text:"Cassidy Civiero",
      texts:"Screenwriter, Director, and Producer",
      url:"/contact-us",
      aboutMe:"Cassidy Civiero is a transgender Screenwriter, Director, and Producer, focussed on content related to mental health and mindfulness, climate change, and gender and sexuality. His work has been screened internationally and funded by several entities including: the Mental Health Commission of California, Art With Impact, the Canadian Media Fund, the Independent Production Fund, Ontario Creates, Bell Fund, Telus Fund, and the Region of Waterloo Arts Fund. ",
      textbook:"Click to Book Cassidy"
      },
      {    
        imageUrl:"/assets/virtualmemberImages/Tony-Hipwell.jpg",
        text:"Tony Hipwell",
        texts:"FilmMaker",
        url:"/contact-us",
        aboutMe:"Tony Hipwell is a multi-award-winning filmmaker whose work has screened at Academy Award, Canadian Screen Award, BAFTA and BIFA qualifying festivals such as HollyShorts, Fantasia and the Edinburgh Film Festival. Their debut feature, Whoops! premiered at Raindance and made the Top Ten picks of 2013. It was also the only British film selected for the nationwide Raindance Tour the following year. Since then, Tony has developed projects with the BBC and Searchlight Pictures, worked as the Video Producer for Young Thugs Records in association with EMI and been selected for the inaugural Future of Film and LHS X FEAR incubators.",
        textbook:"Click to Book Tony"
        },
        {    
          imageUrl:"/assets/virtualmemberImages/Liam-Regan.jpg",
          text:"Liam Regan",
          texts:"Writer, Filmmaker, Producer, Director",
          url:"/contact-us",
          aboutMe:"Liam Regan is an independent filmmaker from South Yorkshire, UK with two feature length productions under his belt: My Bloody Banjo (2015) and it's spiritual sequel Eating Miss Campbell (2022) produced by the president of Troma Entertainment and the creator of The Toxic Avenger (1984). Lloyd Kaufman states: “Liam Regan is the next Eli Roth, James Gunn and Samuel L. Jackson to emerge from the loins of Troma, all wrapped up in one magnificent visionary cinematic burrito!”",
          textbook:"Click to Book Liam"
          },
          {    
            imageUrl:"/assets/virtualmemberImages/Melanie-Gourlay-Director.jpg",
            text:"Melanie Gourlay",
            texts:"filmmaker",
            url:"/contact-us",
            aboutMe:"Mel is a self -taught filmmaker with over 15 year's; experience producing short films and showing them at festivals around the world. She is passionate about sharing the filmmaking process and supporting new filmmakers to realise their potential. 'Seepers: A Love Story' is her first feature film, her second feature, 'They Fuck Y@u Up' is currently in production.",
            textbook:"Click to Book Melanie"
            },
            {
              imageUrl:"/assets/virtualmemberImages/Milethia-Thomas.png",
              text:"Milethia Thomas",
              texts:"writer, director",
              url:"/contact-us",
              aboutMe:"Milethia is an award-winning writer who writes short and full-length screenplays, short stories and plays. In 2017 she worked with the team at LTBL Productions to film her short script 'Francis of Fell End Farm' for  Create50's The Impact, which is a feature film in development; in the Autumn of 2018, the film won an award at the London Screenwriters Festival/British Screenwriters' Awards. While raising her son and working as a communication support worker for deaf people and people with learning disabilities/difficulties, Milethia continues to write and hopes to produce other short films in the future.",
              textbook:" Click to Book milethia"
            },
            {
              imageUrl:"/assets/virtualmemberImages/steve-pic.jpg",
              text:"Steve Derry",
              texts:"screenwriter, Director",
              url:"/contact-us",
              aboutMe:"Steve first published in a national journal at age fourteen. Later published in a variety of academic and recreational journals and moved into screenwriting in 2011. He has written and produced over 25 short films. Senior writer for the Coders Room, a Colombian-USA based writers collective. Steve is the founder of the Nottingham Shooters in 2012, an East Midlands-based filmmakers meet-up 2020. He also co-founded Star Virtual Cinema, the world's first functioning cinema in a VR world.",
              textbook:" Click to Book Steve"
            },
            {
              imageUrl:"/assets/virtualmemberImages/Ryan_Greenwood_Headshot_BW-Large.jpeg",
              text:"Ryan Greenwood",
              texts:"Experienced Videographer & Filmmaker",
              url:"/contact-us",
              aboutMe:"With a comprehensive skill set acquired over the years, Ryan is proficient in directing, camera operation, lighting setup, and extensive editing using tools such as Premiere Pro, After Effects, Final Cut, Da Vinci Resolve, and Photoshop. His technical abilities also extend to hard surface 3D modelling and basic animation in Blender, alongside a flair for prop, costume, and set design and fabrication.",
              textbook:" Click to Book Ryan"
            },  
            {
              imageUrl:"/assets/virtualmemberImages/Rebecca-Sills-1-scaled.jpeg",
              text:"Rebecca Sills",
              texts:"Filmmaker",
              url:"/contact-us",
              aboutMe:"Rebecca's passion for filmmaking began during covid when she started making wildlife films with her dad in their garden. During lockdown the two of them made three award-winning wildlife documentary films. This sparked something in Rebecca, and she knew in her heart she wanted to be a filmmaker.",
              textbook:" Click to Book Rebecca"
            },  
            {
              imageUrl:"/assets/virtualmemberImages/Jon-Addison-Director-Large.jpeg",
              text:"Jon Addison",
              texts:"Writer, Script Editor",
              url:"/contact-us",
              aboutMe:"As a writer, Jon has a particular love of thrillers and horror. He currently has a portfolio of three features and one TV-pilot script, with another pilot in the works. Jon Addison uses his challenging childhood and early life experiences of paranoia to explore messy, complex characters navigating identity, trauma, and this crazy world we live in.",
              textbook:" Click to Book Jon"
            },

            {imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/AndyField.jpeg",
              text:"Andy Field",
              texts:"Writer, Filmmaker",
              url:"/contact-us",
              aboutMe:"Andy Field co-directed the award-winning artist collective Forest Fringe. His work has been presented at festivals and venues across the world. This is his first feature film with Deborah Pearson.",
              textbook:" Click to Book Andy Field"
            },
            {imageUrl:"/assets/virtualmemberImages/Bradley-Porter-pic.jpeg",
              text:"Bradley Porter",
              texts:"Writer, Director",
              url:"/contact-us",
              aboutMe:"He is a Mentor for the BFI Film Academy & Eastside Educational Trust, working with Young Filmmakers from diverse and less privileged backgrounds on their first Short Films. He is currently developing his first feature, - GOOSE - and has recently completed the Feature Screenplays TIMELIKE and GAP YEAR for Rob Savage and Chris Foggin attached to direct, respectively.",
              textbook:" Click to Book Bradley Porter"
            },
            {imageUrl:"/assets/virtualmemberImages/Riley.jpeg",
              text:"Mortal Self",
              texts:"Filmmaker, Writer, Audio and Visual Production",
              url:"/contact-us",
              aboutMe:"Mortal Self is the interdisciplinary collaborative duo of Riley Teahan and Natalita. Uniquely combining movement, meditation, music, theater and design, they create worlds together. As collaborators they share a commitment to making art that is a channel for the divine, a process for healing, and a celebration of femininity and darkness. Their chosen mediums are attention, prayer, body, and breath. They hope to inspire others to awaken to their own power by returning to nature, to mother, to earth.", 
              textbook:" Click to Book Mortal Self"
            },
            {imageUrl:"/assets/virtualmemberImages/Pijus.jpg",
              text:"Pijus Mačiulskis",
              texts:"Film Director",
              url:"/contact-us",
              aboutMe:" Pijus Mačiulskis is an independent film director from Lithuania and currently based in London and creating since 2015. He has recently finished Film Studies at King's College London, where he learned about the theoretical, social, and philosophical evolution of cinema and creating electronic music.", 
              textbook:" Click to Book Pijus Mačiulskis"
            },
            {imageUrl:"/assets/virtualmemberImages/Ryan-Garretson.jpg",
              text:"Ryan Garretson",
              texts:" Independent Filmmaker and Film Editor",
              url:"/contact-us",
              aboutMe:"Ryan Garretson is a New York-based independent filmmaker and editor specializing in horror. ", 
              textbook:" Click to Book Ryan Garretson"
            },
            {imageUrl:"/assets/virtualmemberImages/Adam-Wollard.png",
            text:"Adam Wollard",
            texts:"Writer",
            url:"/contact-us",
            aboutMe:" Adam Woollard is a writer, actor and battle rapper. ", 
            textbook:" Click to Book Adam Wollard"
          },
          {imageUrl:"/assets/virtualmemberImages/Fergus-March.png",
          text:"Fergus March",
          texts:"Director",
          url:"/contact-us",
          aboutMe:"Fergus March has written, produced, directed and edited hundreds of hours of broadcast television, film and online content. Most of this was comedy, although Fergus also took a couple of years to concentrate on environmental film-making.", 
          textbook:" Click to Book Fergus March"
        },
        {imageUrl:"/assets/virtualmemberImages/James-Wren.png",
          text:"James Wren",
          texts:"Producer",
          url:"/contact-us",
          aboutMe:"James Wren has written and produced both feature and short films, web-series and TV pilots.", 
          textbook:" Click to Book James-Wren"
        },
        {imageUrl:"/assets/virtualmemberImages/Louie-Bayliss.png",
        text:"Louie Bayliss",
        texts:"Producer",
        url:"/contact-us",
        aboutMe:" Louie Bayliss is a writer, actor & filmmaker.", 
        textbook:" Click to Book Louis Bayliss"
      },
      {imageUrl:"/assets/virtualmemberImages/Pablo-Villalobos.jpg",
      text:"Pablo Villalobos",
      texts:"Directot",
      url:"/contact-us",
      aboutMe:" Pablo Villalobos (1995) was born in Zaragoza, Spain. Son of a family of artists Cuban plastic emigrants in Spain in the 90's. In 2015 he graduated in Studies Higher Degrees in Cinematography and Visual Arts at the University School of Arts and  TAI Shows (Madrid, Spain.) That same year he founded his own production company film called VillalobosCine. In 2016 he returned to his land of Cuba, in City of Havana where he resides and works for several years. He currently lives and works in Madrid.", 
      textbook:" Click to Book Pablo Vlillalobos"
    },
  
  ];

 /**the filter grid items based on the search query */

  const filteredGridItems = gridItems.filter((item) =>
    item.text.toLowerCase().includes(search.toLowerCase())||
    item.texts.toLowerCase().includes(search.toLowerCase())
  );


  return (
    <main className="px-10">
      {/* <MainCard>
  <video   
    autoPlay
    loop
    muted
    className="object-cover absolute h-full w-full grayscale"
    src="https://d15gvnltmubede.cloudfront.net/the-kurious-videos/collective-video.mp4"
  />
  <div className="uppercase absolute left-4 top-1/4 lg:top-0 mt-3 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-[10rem] lg:font-extrabold font-bold text-left">
        <span className="tracking-tighter">join the<br/> collective</span> 
        <span className="tracking-tighter flex lg:mt-4 left-4 text-sm lg:text-[3rem]">home for creatives</span>
        </div>

</MainCard> */}
<div className="pt-10">

          <input
           className="max-w"
            type="text"
            placeholder="Search"
            value={search}
            onChange={(e) =>{
              setSearch(e.target.value);
            }
          }                                
          /> 


    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 lg:mt-5">
      

                            {gridItems.map((item) => {
                                        if (item.texts.toLowerCase().includes(search.toLowerCase())||
                                            item.text.toLowerCase().includes(search.toLowerCase())){
                                          return (
                                             <Link key={item.text} href={item.url}>
                                            <GridItem
                                              key={item.text}
                                              imageUrl={item.imageUrl}
                                              text={item.text}
                                              texts={item.texts}
                                              url={item.url}
                                              aboutMe={item.aboutMe}
                                              textbook={item.textbook}
                                            />
                                            </Link>
                                          );
                                        }
                                        return null; // Hide non-matching items
                                      })}
                                      
            </div>
            
    </div>
    
    <div className="w-full mt-5 ">
        <ul className="flex mb-2 md:justify-end md:gap-4 justify-between text-2xl items-center ">
          <li>
          <Link href='https://www.instagram.com/thekurious_/'>
            <BiLogoInstagram />
            </Link>
          </li>
          <li>
          <Link href='https://www.facebook.com/people/The-Kurious/100079157044792/'>
            <FaFacebookF />
            </Link>
          </li>
          <li>
          <Link href='https://twitter.com/thekurious_'>
            <FaXTwitter />
            </Link>
          </li>
          <li>
          <Link href='https://www.tiktok.com/@thekurious_'>
            <BiLogoTiktok />
            </Link>
          </li>
          <li>
          <Link href='tel:01143123659'>
            <FiPhoneCall />
            </Link>
          </li>
          {/* <Link href="#">
            <li className="px-2 py-1 text-sm md:text-lg bg-primary rounded-lg shadow-md ">
              BOOK NOW
            </li>
          </Link> */}
        </ul>
      </div>

</main>
  );
};

export default Creators;
