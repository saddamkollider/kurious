"use client"
import MainCard from "@/components/ui/MainCard";
import type { FC } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import { Carousel } from 'react-responsive-carousel';
import {FaBackward} from 'react-icons/fa';
import {FaForward} from 'react-icons/fa';
import Link from "next/link";
import SocialLink from "@/components/ui/SociMediaIcon/page";
interface CreativeProps {}

const Creative: FC<CreativeProps> = () => {
  return (
    <main className="px-10">
    
    <Carousel showIndicators={false} 
     showArrows={false} showStatus={false} showThumbs={false}
     renderArrowPrev={(clickHandler) => (
       <button onClick={clickHandler} className="arrow-button absolute lg:text-5xl text-3xl z-10 top-2/4 text-primary">
         <FaBackward/>
       </button>
     )}
     renderArrowNext={(clickHandler) => (
       <button onClick={clickHandler} className="arrow-button absolute  lg:text-5xl text-3xl right-2  top-2/4 text-primary">
         <FaForward/>
       </button>
     )}> 
    
       
       
         <MainCard>
        <img
          className="object-cover h-full w-full grayscale"
          src="/pictures/Allfilmfinal.png"
          alt="Allfilm"
        />

       <div className="absolute font-semibold  md:left-10 top-5 left-4 text-white text-5xl  md:text-7xl lg:text-[18rem] " style={{fontFamily:'Arial Narrow'}}>
          <span style={{textDecoration:'underline'  }}>All</span>
          <span className="text-[#ffd831]">Film</span>
        </div>
          
        <div className="uppercase absolute bottom-14 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-5xl font-bold text-left">
        <span>Explore the <br/>indie film maker<br/>Universe</span> 
        </div> <Link href="https://allfilm.co.uk" target="_blank" rel="noopener noreferrer">
        <div className="absolute z-30 bottom-2 left left-5 lg:left-8 lg:text-2xl text-2xl text-primary font-bold "> Click to see more </div></Link>
      </MainCard>
    
   
     
     
      <MainCard>
        <img
          
          className="object-cover h-full w-full grayscale"
          src="/pictures/Allstorefinal.png"
          alt="Allstore"
                   
        />
  
        <div className="absolute font-semibold  md:left-10 top-5 left-4 text-white text-5xl  md:text-7xl lg:text-[18rem] " style={{fontFamily:'Arial Narrow'}}>
          <span style={{textDecoration:'underline'  }}>All</span>
          <span className="text-[#ffd831]">Store</span>
        </div>
        

        <div className="uppercase absolute bottom-14 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-5xl font-bold text-left">
        <span>have it all <br/>your one stop</span> 
        </div> <Link href="https://theallstore.co.uk/" target="_blank" rel="noopener noreferrer">
        <div className="absolute bottom-2 left left-5 lg:left-8 lg:text-2xl text-2xl text-primary font-bold "> Click to see more </div></Link>
      </MainCard>
       
   
        <MainCard>
        <img
          className="object-cover h-full w-full grayscale"
          src="/assets/events.jpg"
          alt="the-kurius event image"
                   
        />
        <div className="absolute font-semibold  md:left-10 top-5 left-4 text-white text-5xl  md:text-7xl lg:text-[18rem] " style={{fontFamily:'Arial Narrow'}}>
          <span style={{textDecoration:'underline'  }}>All</span>
          <span className="text-[#ffd831]">Events</span>
        </div>
        

        <div className="uppercase absolute bottom-14 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-5xl font-bold text-left">
        <span>spaces<br/>events</span> 
        </div>


      </MainCard>

    </Carousel>  
    <SocialLink/>

    </main>
  );
};

export default Creative;