"use client"
import MainCard from "@/components/ui/MainCard";
import Typewrite from "@/components/ui/TypeRight";
import type { FC } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import React, { useState } from 'react';
import {BiCameraMovie} from 'react-icons/bi';
import {FaAward} from 'react-icons/fa';
interface ProfileProps {}



 
const Profile: FC<ProfileProps> = () => {


                /*the toggle function for the profile content*/

           const [isFullContent, setIsFullContent] = useState(false);
                    
           const toggleContent = () => {
             setIsFullContent(!isFullContent);
           };
           const fullContent = `Born in Cape Town, South Africa, where he grew up and went to university, Benedict grew up with music around him, learning to play the cello, piano and percussion. He studied music at school and university with harmony and learning to compose early on, composing for plays (including some of Shakespeare’s plays), he has always been fascinated with the use of music in films. Although with a classical upbringing and learning to read and write music in the notation style, he has been developing his skills with synthesised music, doing a Masterclass with Hans Zimmer to further develop it.

           Benedict has had quite a wide experience with TV and film, running a company, CZA Studios for 2D and 3D animation, specialising in whiteboard animation for companies like PwC and McKinsey and Co. He has also provided zooming in from space to a specific play in Manchester for the BBC series, The Body Farm and also providing interactive coding for BBC series like Inspector Lewis and Hustle.
           
           Other than his work for Google Digital Garage (and Google New Initiative) as broadcaster, lead talker and moderator and all of his background in animation and film, Benedict is now centring his work on his first love, composing for film.`;




  return (
    <main className="ml-[5%] md:mt-2 xl:mt-2 mt-5 lg:mt-7  mr-[5%] lg:ml-[2.5%] lg:mr-[2.5%] xl:ml-[3%] xl:mr-[3%] h-full lg:h-full">

            <div className=''>
                  <div className="flex flex-col">
                                  <div className="grid lg:grid-cols-6 grid-cols-1 lg:mt-5 gap-0 flex-1 bg-white" >
                                    <div className="bg-[#ffd831]">
                                      <img src="https://d15gvnltmubede.cloudfront.net/creators-pictures/benedictprofile.png" alt="Profileimage"/>

                                      <div className=" mt-10 flex flex-col items-center justify-center">
                                  <ul className="space-y-2">
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white cursor-pointer"
                                      >
                                        Home
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        About Me
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Resume
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Portfolio
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Testimonials
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="https://www.cognitoforms.com/f/TBvlivnYu0qXj9F9C55Oqg/128"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Contact
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                  </ul>
                                </div>


                                    </div>
                                                      <div className="col-span-5 bg-white">
                                                        <h1 className="flex lg:text-6xl text-2xl items-center font-bold justify-center border-4 border-[#a3aea9] mt-5 lg:ml-16 mr-5 h-20">ABOUT ME</h1>
                                                        <h1 className='text-left font-extralight text-3xl lg:ml-16 ml-4 mt-5'> I am <strong>Benedict,</strong> A Composer</h1>
                                                         
                                                        <div className=" text-justify mx-auto max-w-screen-md md:max-w-screen-md p-4 lg:max-w-screen-xl xl:max-w-screen-2xl lg:pl-16 lg:pr-16">
                                                                            {isFullContent ? (
                                                                              <div className="mb-2">
                                                                                {fullContent.split('\n').map((paragraph, index) => (
                                                                                  <p key={index} className="my-2">{paragraph}</p>
                                                                                ))}
                                                                              </div>
                                                                            ) : (
                                                                              <div className="mb-2">
                                                                                {fullContent.slice(0, 400).split('\n').map((paragraph, index) => (
                                                                                  <p key={index} className="my-2">{paragraph}</p>
                                                                                ))}
                                                                              </div>
                                                                            )}
                                                                            {isFullContent ? (
                                                                              <button onClick={toggleContent} className="text-blue-500 hover:underline">
                                                                                Read Less
                                                                              </button>
                                                                            ) : (
                                                                              <button onClick={toggleContent} className="text-blue-500 hover:underline">
                                                                                Read More
                                                                              </button>
                                                                            )}
                                                                          </div>


                                                                        <div className="grid lg:grid-cols-4 grid-cols-1 lg:gap-10 gap-0 mt-1 lg:mt-0">
                                                                          <div className="grid col-span-3 lg:ml-16   mb-4 ">
                                                                            <video autoPlay loop muted controls className='w-full'>
                                                                              <source src="Ryan-AD_TRAILER_FOR_KURIOUS_WEB.mp4" type="video/mp4" />
                                                                            </video>
                                                                          </div>
                                                                          <div className="">
                                                                            <div className='text-2xl lg:text-3xl md:text-2xl xl:text-3xl font-bold'>Awards & Credits</div>
                                                                            <div className='grid grid-cols-4 lg:grid-cols-4 md:grid-cols-4 mt-5'>

                                                                          <div className="flex flex-col md:items-center">
                                                                          <div className="mb-14 md:mb-5 lg:mb-16">
                                                                          <FaAward className="text-6xl" />
                                                                        </div>
                                                                          <div className="mb-10 md:mb-5 lg:mb-24">
                                                                            <FaAward className="text-6xl" />
                                                                            </div>
                                                                                <div className="mb-10 md:mb-5">
                                                                              <FaAward className="text-6xl" />
                                                                              </div>
                                                                             
                                                                              
                                                                                    </div>
                                                                            <div className='col-span-3'>
                                                                            <div className='mb-8 mt-1'>
                                                                              <h1 className='font-bold'>Awards & Credits</h1>
                                                                              <p className='font-sans w-full justify-normal'>-Official Selection of Animart Film Festival 2021
                                                                                </p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10 mt-0'>
                                                                              <h1 className='font-bold'>Awards & Credits</h1>
                                                                              <p>-Official Selection & Highly Commended by Cinemagic <br/>Young Film Makers Festival 2020</p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10'>
                                                                              <h1 className='font-bold'>Awards & Credits</h1>
                                                                              <p>-Finalist in the Virgin Money Shorts Competition in 2018</p>
                                                                              </div>
                                                                             
                                                                            
                                                                            </div>

                                                                            </div>
                                                                          
                                                                          </div>
                                                                          
                                                                        </div>
                                                      </div>
                                  </div>



                                  


                  </div>
    </div>
    

                
    </main>
  );
};

export default Profile;