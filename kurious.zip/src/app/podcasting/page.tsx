'use client'
import React, { FC, useState } from "react";

import Link from "next/link";

import ProductArticle from "@/components/ui/ProductionArticle";


interface CreatorsProps { }

const Creators: FC<CreatorsProps> = () => {

  return (
    <main className="mx-10">

      <Banner />
      <section className="max-w-8xl mx-auto my-5 text-lg ">
 
          <ProductArticle paragraph="Designed to enhance every aspect of your production. Whether you want to be on a desk and chair, relaxed on a sofa, sit by the bar or you prefer to stand in the audio booth, we have all the sets to fit your style." heading="Elevate your podcasting experience with our premium podcast suite and residential sound technician."/>
         
        <div className="grid mx-auto lg:grid-rows-2 lg:grid-cols-2 gap-3  mt-5">
          <div className="row-span-2">
            {/* short$featured film video */}
          <VideoHoverCard 
          videoUrl={"/assets/podcasting/"} 
          imgUrl={"/assets/podcasting/podcastingportrait.jpg"}
          title=""/>
          </div>
                {/* documentory video */}
          <VideoHoverCard 
          videoUrl={"/assets/podcasting/podcasting01.mp4"} 
          imgUrl={"/assets/podcasting/PODCAST-STUDIO.jpg"}
          title=""/>
          {/* Animations video */}
          <VideoHoverCard 
          videoUrl={"/assets/filmproduction-contents/"}  
          imgUrl={"/assets/podcasting/Podcasting.jpeg"}
          title=""/>
        </div>
      </section>
    </main>
  );
};

export default Creators;

const Banner = () => {
  return (<>

    <div className="lg:w-full lg:h-[32vh] h-[10vh]  bg-[#2a2a2a] mt-5 flex items-center">
      <article className="uppercase text-2xl lg:text-5xl font-bold  mx-auto  ">
        <p className="border-b-4 text-white w-fit tracking-wide leading-snug border-yellow-300">
          Podcasting
        </p>
      </article>
    </div>
  </>)
}

interface VideoHoverCardProps{
  videoUrl:string;
  imgUrl:string;
  title: string;
}

const VideoHoverCard : React.FC<VideoHoverCardProps>=({videoUrl,imgUrl,title}) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleHover = () => {
    setIsHovered(true);
  };

  const handleLeave = () => {
    setIsHovered(false);
  };

  return (
   
    <div
    className={`relative group h-full overflow-hidden ${isHovered ? 'hovered' : ''}`}
    onMouseEnter={handleHover}
    onMouseLeave={handleLeave}
  >
    <div className="bg-white border w-full border-gray-200 h-full shadow relative overflow-hidden">
      
        <div className="absolute w-full h-full transition-transform duration-300 transform group-hover:scale-10 object-cover rounded-lg flex top-2 left-3 text-white z-10">
          <p className="text-lg text-white font-bold lg:text-4xl">{title}</p>
        </div>
      
      <img
        className="object-cover w-full h-full transition-transform duration-300 transform group-hover:scale-105"
        src={imgUrl} // Replace with your image URL
        alt="img"
      />
      {isHovered && (
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover rounded-lg"
          controlsList="nodownload"
        >
          <source
            src={videoUrl} // Replace with your video URL
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      )}
    </div>
  </div>
  );
};

