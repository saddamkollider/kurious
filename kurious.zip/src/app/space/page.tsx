"use client";
import MainCard from "@/components/ui/MainCard";
import { useState, type FC } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import { FaBackward } from "react-icons/fa";
import { FaForward } from "react-icons/fa";
import GalleryPopUp from "@/components/ui/GalleryPopup";
import SocialLink from "@/components/ui/SociMediaIcon/page";
interface CreativeProps {}

const Creative: FC<CreativeProps> = () => {
  const [openModal, setOpenModal] = useState(false);
  const [ImageList, setImageList] = useState<React.ReactElement[]>([]);
  return (
    <main className="px-10">
      <GalleryPopUp
        imageList={ImageList}
        modalState={{ openModal: openModal, setOpenModal: setOpenModal }}
      />
      <Carousel
        showArrows={false}
        showStatus={false}
        showThumbs={false}
        // showIndicators={false}
        renderArrowPrev={(clickHandler) => (
          <button
            onClick={clickHandler}
            className="arrow-button absolute  lg:text-5xl text-3xl z-10 top-2/4 text-primary"
          >
            <FaBackward />
          </button>
        )}
        renderArrowNext={(clickHandler) => (
          <button
            onClick={clickHandler}
            className="arrow-button absolute lg:text-5xl text-3xl right-2  top-2/4 text-primary"
          >
            <FaForward />
          </button>
        )}
      >
        <MainCard>
          <img
            className="object-cover h-full w-full grayscale"
            src="https://d15gvnltmubede.cloudfront.net/The-kurious/SPACE-IMAGE/soundsuite1.jpg"
            alt="Sound Suite image"
          />

          <div className="uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left">
            <span>
              Sound
              <br />
              Suites
            </span>
          </div>
          <div
            onClick={() => {
              setOpenModal(true);
              setImageList([
                <img
                  key={"soundsuite1"}
                  className="object-cover h-full w-full"
                  src="assets/Space-soundImage/space2.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"soundsuite2"}
                  className="object-cover h-full"
                  src="assets/Space-soundImage/space3.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"soundsuite3"}
                  className="object-cover h-full"
                  src="assets/Space-soundImage/space4.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"soundsuite4"}
                  className="object-cover h-full"
                  src="assets/Space-soundImage/space4.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"soundsuite5"}
                  className="object-cover h-full"
                  src="assets/Space-soundImage/space6.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"soundsuite6"}
                  className="object-cover h-full"
                  src="assets/Space-soundImage/space7.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"soundsuite7"}
                  className="object-cover h-full"
                  src="assets/Space-soundImage/space9.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"soundsuite8"}
                  className="object-cover h-full"
                  src="assets/Space-soundImage/space10.jpg"
                  alt="kurious- Images"
                />,
              ]);
            }}
            className="absolute cursor-pointer bottom-5 md:bottom-10 z-10 text-primary left-5 md:left-10 md:text-2xl font-semibold"
          >
            Click to see more
          </div>
        </MainCard>
        <MainCard>
          <img
            className="object-cover h-full w-full grayscale"
            src="https://d15gvnltmubede.cloudfront.net/The-kurious/SPACE-IMAGE/edit-suite.jpg"
            alt="Edit Suite image"
          />
          <div className="uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left">
            <span>
              Edit
              <br />
              Suite
            </span>
          </div>
          <div
            onClick={() => {
              setOpenModal(true);
              setImageList([
                <img
                  key={"edit-suite01"}
                  className="object-cover h-full"
                  src="assets/Space-editSuiteImage/edit-suite6.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"edit-suite02"}
                  className="object-cover h-full"
                  src="assets/Space-editSuiteImage/edit-suite2.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"edit-suite03"}
                  className="object-cover h-full"
                  src="assets/Space-editSuiteImage/edit-suite3.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"edit-suite05"}
                  className="object-cover h-full"
                  src="assets/Space-editSuiteImage/edit-suite5.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"edit-suite06"}
                  className="object-cover h-full"
                  src="assets/Space-editSuiteImage/edit-suite8.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"edit-suite02"}
                  className="object-cover h-full"
                  src="assets/Space-editSuiteImage/edit-suite11.jpg"
                  alt="kurious- Images"
                />,
              ]);
            }}
            className="absolute cursor-pointer bottom-5 md:bottom-10 z-10 text-primary left-5 md:left-10 md:text-2xl font-semibold"
          >
            Click to see more
          </div>
        </MainCard>
        <MainCard>
          <img
            className="object-cover h-full w-full grayscale"
            src="https://d15gvnltmubede.cloudfront.net/The-kurious/SPACE-IMAGE/production-space.JPG"
            alt="Production Space image"
          />

          <div className="scroll- uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left">
            <span>
              Production
              <br />
              space
            </span>
          </div>
          <div
            onClick={() => {
              setOpenModal(true);
              setImageList([
                <img
                  key={"production-space01"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace1.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space02"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace2.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space03"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace3.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space04"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace4.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space05"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace5.JPG"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space06"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace6.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space07"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace7.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space08"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace8.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"production-space09"}
                  className="object-cover h-full"
                  src="assets/Space-productionImage/productionspace9.jpg"
                  alt="kurious- Images"
                />,
              ]);
            }}
            className="absolute cursor-pointer bottom-5 md:bottom-10 z-10 text-primary left-5 md:left-10 md:text-2xl font-semibold"
          >
            Click to see more
          </div>
        </MainCard>
        {/* <MainCard>
          <img
            className="object-cover h-full w-full grayscale"
            src="https://d15gvnltmubede.cloudfront.net/The-kurious/SPACE-IMAGE/photogray-space.jpg"
            alt="Photography Space image"
          />

          <div className="uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left">
            <span>
              Photography
              <br />
              space
            </span>
          </div>
          <div
            onClick={() => {
              setOpenModal(true);
              setImageList([
                <img
                  key={"photography-space01"}
                  className="object-cover h-full"
                  src="assets/Space-photographyImage/studio.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"photography-space02"}
                  className="object-cover h-full"
                  src="assets/Space-photographyImage/studio3.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"photography-space03"}
                  className="object-cover h-full"
                  src="assets/Space-photographyImage/studio5.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"photography-space04"}
                  className="object-cover h-full"
                  src="assets/Space-photographyImage/studio7.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"photography-space05"}
                  className="object-cover h-full"
                  src="assets/Space-photographyImage/studio9.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"photography-space06"}
                  className="object-cover h-full"
                  src="assets/Space-photographyImage/studio11.jpg"
                  alt="kurious- Images"
                />,
                <img
                  key={"photography-space07"}
                  className="object-cover h-full"
                  src="assets/Space-photographyImage/studio12.jpg"
                  alt="kurious-Images"
                />,
              ]);
            }}
            className="absolute cursor-pointer bottom-5 md:bottom-10 z-10 text-primary left-5 md:left-10 md:text-2xl font-semibold"
          >
            Click to see more
          </div>
        </MainCard> */}
      <MainCard>
        <img
          className="object-cover h-full w-full grayscale"
          src="/assets/events.jpg"
          alt="Event Space image"
                   
        />
      
        <div className="uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left">
                <span>Event<br/>space</span>
            </div>
            <div onClick={()=>{setOpenModal(true)
        setImageList([ <img key={'event-space01'}  className='object-cover h-full' src="assets/Space-eventsImages/events1.jpg" alt="kurious- Images"/>, <video key={'event-space02'} className="object-cover h-full" autoPlay muted src="assets/Space-eventsImages/Thekurious-Smyca-Loopassemble.mp4"/>, <img key={'event-space03'} className='object-cover h-full' src="assets/Space-eventsImages/events2.jpg" alt="kurious- Images"/>])
        
        }} className="absolute cursor-pointer bottom-5 md:bottom-10 z-10 text-primary left-5 md:left-10 md:text-2xl font-semibold">
          Click to see more
        </div>
       
      </MainCard>
    </Carousel>  
    <SocialLink/>
   
    </main>
  );
};

export default Creative;
