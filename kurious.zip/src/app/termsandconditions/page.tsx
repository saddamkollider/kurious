"use client"
import { FC } from 'react';

import 'react-responsive-carousel/lib/styles/carousel.min.css';

interface TermsProps {}

const Terms: FC<TermsProps> = () => {
  return (
    <main className="px-10">
      <div className="lg:mt-10 mt-5 text-justify">
    
    <h1 className="font-bold mb-4"> PLEASE READ THESE TERMS AND CONDITIONS CAREFULLY BEFORE USING THIS SITE</h1>
    
    <h2 className='lg:mb-2 mb-2 font-bold'> WHAT’S IN THESE TERMS?</h2>
    
    <p className='mb-2 lg:mb-2'>These terms tell you the rules for using our website KuriousArts.co.uk (our site).</p>
    
    <p className='lg:mb-2 mb-2 font-bold'> WHO WE ARE AND HOW TO CONTACT US </p>
    
    <p  className='mb-2 lg:mb-2'><span className='font-bold'>The-KuriousArts.co.uk </span> is a site operated by the Kollider group of companies, comprising Kollider Incubator Limited (CRN 12741177), and Kurious Arts Limited (CRN 12140186), (we, us, our), each company being a company limited by shares.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'> BY USING OUR SITE YOU ACCEPT THESE TERMS</p>
    
    <p className='mb-2 lg:mb-2'> By using our site, you confirm that you accept these terms of use and that you agree to comply with them.</p>
    
    <p className='mb-2 lg:mb-2'> If you do not agree to these terms, you must not use our site.</p>
    
    <p className='mb-2 lg:mb-2'> We recommend that you print a copy of these terms for future reference.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'> THERE ARE OTHER TERMS THAT MAY APPLY TO YOU</p>
    
    <p className='mb-2 lg:mb-2'> These terms of use refer to the following additional terms, which also apply to your use of our site:</p>
    
    <p className='mb-2 lg:mb-2' >our Privacy Policy.</p>
    
    <p className='mb-2 lg:mb-2'> our Acceptable Use Policy, which sets out the permitted uses and prohibited uses of our site. When using our site, you must comply with this Acceptable Use Policy.</p>
    
    <p className='mb-2 lg:mb-2'> our Cookie Policy, which sets out information about the cookies on our site.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>WE MAY MAKE CHANGES TO THESE TERMS</p>
    
    <p className='mb-2 lg:mb-2'> We amend these terms from time to time. Every time you wish to use our site, please check these terms to ensure you understand the terms that apply at that time.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>WE MAY MAKE CHANGES TO OUR SITE</p>
    
    <p className='mb-2 lg:mb-2'> We may update and change our site from time to time to reflect our users’ needs and our business priorities.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'> WE MAY SUSPEND OR WITHDRAW OUR SITE</p>
    
    <p className='mb-2 lg:mb-2'>Our site is made available free of charge.</p>
    
    <p className='mb-2 lg:mb-2'>We do not guarantee that our site, or any content on it, will always be available or be uninterrupted. We may suspend or withdraw or restrict the availability of all or any part of our site for business and operational reasons. We will try to give you reasonable notice of any suspension or withdrawal.</p>
    
    <p className='mb-2 lg:mb-2'> You are also responsible for ensuring that all persons who access our site through your internet connection are aware of these terms of use and other applicable terms and conditions, and that they comply with them.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>WE MAY TRANSFER THIS AGREEMENT TO SOMEONE ELSE</p>
    
    <p className='mb-2 lg:mb-2'>We may transfer our rights and obligations under these terms to another organisation. We will always tell you in writing if this happens and we will ensure that the transfer will not affect your rights under the contract.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'> HOW YOU MAY USE MATERIAL ON OUR SITE</p>
    
    <p className='mb-2 lg:mb-2'>We are the owner or the licensee of all intellectual property rights in our site, and in the material published on it. Those works are protected by copyright laws and treaties around the world. All such rights are reserved. You may print off one copy, and may download extracts, of any page(s) from our site for your personal use and you may draw the attention of others within your organisation to content posted on our site.</p>
    
    <p className='mb-2 lg:mb-2'> You must not modify the paper or digital copies of any materials you have printed off or downloaded in any way, and you must not use any illustrations, photographs, video or audio sequences or any graphics separately from any accompanying text.</p>
    
    <p className='mb-2 lg:mb-2'> Our status (and that of any identified contributors) as the authors of content on our site must always be acknowledged.</p>
    
    <p className='mb-2 lg:mb-2'>You must not use any part of the content on our site for commercial purposes without obtaining a licence to do so from us or our licensors.</p>
    
    <p className='mb-2 lg:mb-2'> If you print off, copy or download any part of our site in breach of these terms of use, your right to use our site will cease immediately and you must, at our option, return or destroy any copies of the materials you have made.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>DO NOT RELY ON INFORMATION ON THIS SITE</p>
    
    <p className='mb-2 lg:mb-2'>The content on our site is provided for general information only. It is not intended to amount to advice on which you should rely. You must obtain professional or specialist advice before taking, or refraining from, any action on the basis of the content on our site.</p>
    
    <p className='mb-2 lg:mb-2'> Although we make reasonable efforts to update the information on our site, we make no representations, warranties or guarantees, whether express or implied, that the content on our site is accurate, complete or up to date.</p>
    
    <p className='mb-2 lg:mb-2'> WE ARE NOT RESPONSIBLE FOR WEBSITES WE LINK TO</p>
    
    <p className='mb-2 lg:mb-2'> Where our site contains links to other sites and resources provided by third parties, these links are provided for your information only. Such links should not be interpreted as approval by us of those linked websites or information you may obtain from them.</p>
    
    <p className='mb-2 lg:mb-2'> We have no control over the contents of those sites or resources.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>HOW TO COMPLAIN ABOUT CONTENT UPLOADED BY OTHER USERS</p>
    
    <p  className='mb-2 lg:mb-2'>If you wish to complain about content uploaded by other users, please contact us on KuriousArts.co.uk.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>OUR RESPONSIBILITY FOR LOSS OR DAMAGE SUFFERED BY YOU</p>
    
    <p className='mb-2 lg:mb-2'>Whether you are a consumer or a business user:</p>
    
    <p className='mb-2 lg:mb-2'>We do not exclude or limit in any way our liability to you where it would be unlawful to do so. This includes liability for death or personal injury caused by our negligence or the negligence of our employees, agents or subcontractors and for fraud or fraudulent misrepresentation.</p>
    
    <p className='mb-2 lg:mb-2'>If you are a business user:</p>
    
    <p className='mb-2 lg:mb-2'>We exclude all implied conditions, warranties, representations or other terms that may apply to our site or any content on it.</p>
    
    <p className='mb-2 lg:mb-2'>We will not be liable to you for any loss or damage, whether in contract, tort (including negligence), breach of statutory duty, or otherwise, even if foreseeable, arising under or in connection with the use of, or inability to use, our site or the use of or reliance on any content displayed on our site.</p>
    
    <p className='mb-2 lg:mb-2'>If you are a consumer user:</p>
    
    <p className='mb-2 lg:mb-2'>Please note that we only provide our site for private use. You agree not to use our site for any commercial or business purposes, and we have no liability to you for any loss of profit, loss of business, business interruption, or loss of business opportunity.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>HOW WE MAY USE YOUR PERSONAL INFORMATION</p>
    
    <p className='mb-2 lg:mb-2'>We will only use your personal information as set out in our privacy policy.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>UPLOADING CONTENT TO OUR SITE</p>
    
    <p className='mb-2 lg:mb-2'>Whenever you make use of a feature that allows you to upload content to our site, or to make contact with other users of our site, you must comply with the content standards set out in our Acceptable Use Policy.</p>
    
    <p className='mb-2 lg:mb-2'>You warrant that any such contribution does comply with those standards, and you will be liable to us and indemnify us for any breach of that warranty. This means you will be responsible for any loss or damage we suffer as a result of your breach of warranty.</p>
    
    <p className='mb-2 lg:mb-2'>Any content you upload to our site will be considered non-confidential and non-proprietary. You retain all of your ownership rights in your content, but you are required to grant us and other users of our site a limited licence to use, store and copy that content and to distribute and make it available to third parties. We also have the right to disclose your identity to any third party who is claiming that any content posted or uploaded by you to our site constitutes a violation of their intellectual property rights, or of their right to privacy.</p>
    
    <p className='mb-2 lg:mb-2'>  We have the right to remove any posting you make on our site if, in our opinion, your post does not comply with the content standards set out in our Acceptable Use Policy</p>
    
    <p>You are solely responsible for securing and backing up your content.</p>
    
    <p className='mb-2 lg:mb-2'>We do not store terrorist content.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>RIGHTS YOU ARE GIVING US TO USE MATERIAL YOU UPLOAD</p>
    
    <p className='mb-2 lg:mb-2'>When you upload or post content to our site, you grant us the following rights to use that content:</p>
    
    <p className='mb-2 lg:mb-2'>a worldwide, non-exclusive, royalty-free, transferable licence to use, reproduce, distribute, prepare derivative works of, display, and perform that user-generated content in connection with the service provided by the website and across different media including to promote the site or the service; and
    
        a worldwide, non-exclusive, royalty-free, transferable licence for other users, partners or advertisers to use the content for their purposes.</p>
    
    <p className='lg:mb-2 mb-2 font-bold' >WE ARE NOT RESPONSIBLE FOR VIRUSES AND YOU MUST NOT INTRODUCE THEM</p>
    
    <p className='mb-2 lg:mb-2'>We do not guarantee that our site will be secure or free from bugs or viruses.</p>
    
    <p className='mb-2 lg:mb-2'>You are responsible for configuring your information technology, computer programmes and platform to access our site. You should use your own virus protection software.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>RULES ABOUT LINKING TO OUR SITE</p>
    
    <p className='mb-2 lg:mb-2'>You may link to our home page, provided you do so in a way that is fair and legal and does not damage our reputation or take advantage of it.</p>
    
    <p className='mb-2 lg:mb-2'>You must not establish a link in such a way as to suggest any form of association, approval or endorsement on our part where none exists.</p>
    
    <p className='mb-2 lg:mb-2'>You must not establish a link to our site in any website that is not owned by you.</p>
    
    <p className='mb-2 lg:mb-2'>Our site must not be framed on any other site, nor may you create a link to any part of our site other than the home page.</p>
    
    <p className='mb-2 lg:mb-2'>We reserve the right to withdraw linking permission without notice.</p>
    
    <p className='mb-2 lg:mb-2'>The website in which you are linking must comply in all respects with the content standards set out in our Acceptable Use Policy.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>WHICH COUNTRY’S LAWS APPLY TO ANY DISPUTES?</p>
    
    <p className='mb-2 lg:mb-2'> If you are a consumer, please note that these terms of use, their subject matter and their formation, are governed by English law. You and we both agree that the courts of England and Wales will have exclusive jurisdiction except that if you are a resident of Northern Ireland you may also bring proceedings in Northern Ireland, and if you are resident of Scotland, you may also bring proceedings in Scotland.</p>
    
    <p className='mb-2 lg:mb-2'>If you are a business, these terms of use, their subject matter and their formation (and any non-contractual disputes or claims) are governed by English law. We both agree to the exclusive jurisdiction of the courts of England and Wales.</p>
    
    <p className='lg:mb-2 mb-2 font-bold'>OUR TRADE MARKS ARE REGISTERED</p>
    
    <p className='mb-2 lg:mb-2'>Trademarks used on our website (including the below) are owned by one of the Kollider group of companies, Kollider Projects Limited (CRN 10167392), Kurious Arts Limited (CRN 12140186) or Kollider Social Limited (CRN11119868). You are not permitted to use them without our approval.</p>
    
    
    </div>
    </main>
  );
};

export default Terms;