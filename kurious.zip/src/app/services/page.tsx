"use client"
import MainCard from "@/components/ui/MainCard";
import type { FC } from "react";
import React from 'react';
import Link from "next/link";
import SocialLink from "@/components/ui/SociMediaIcon/page";
interface ServicesProps {}


const GridItem = ({ imageUrl, text,text2 }: { imageUrl: string; text: string; text2:string}) => (
  <div className="relative group">
    <div
      className="bg-cover bg-center h-64 md:h-72 lg:h-96 bg-no-repeat"
      style={{ backgroundImage: `url(${imageUrl})` }}
    >
      <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-50 transition duration-300"></div>
    </div>
    <div className="absolute bottom-2 ml-4 text-left">
      <p className="text-white text-lg md:text-xl lg:text-4xl font-semibold uppercase">{text}</p>
      <p className="text-white -mt-2 text-lg md:text-xl lg:text-4xl font-semibold uppercase">{text2}</p>
    </div>
  </div>
);



const Services: FC<ServicesProps> = () => {
  return (
    <main className="px-10">
      <MainCard>
  <video
    autoPlay
    loop
    muted
    className="object-cover absolute h-full w-full grayscale"
    src="https://d15gvnltmubede.cloudfront.net/the-kurious-videos/KURIOUS Services.mp4"
  />
  <div className="uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left">
        <span>Services</span> 
        </div>

  <div className="absolute bottom-5 right-3">
    {/* <button className="bg-[#ffd831] hover:bg-[#ffe54a] text-black font-semibold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105">
      Contact Us
    </button> */}
  </div>
</MainCard>
<SocialLink/>
<div>


    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 lg:mt-5">
     
           <Link href="/postproduction"><GridItem
              imageUrl="https://d15gvnltmubede.cloudfront.net/The-kurious/SERVICES-IMAGES/KURIOUS03112021.jpg"
              text="post"
              text2="production"
            />
            </Link>
            <Link href="/filmproduction"><GridItem
              imageUrl="https://d15gvnltmubede.cloudfront.net/The-kurious/SERVICES-IMAGES/KURIOUS-FILM-PRODUCTION.png"
              text="Film"
              text2="Production"
            />
            </Link>
            <Link href="/podcasting"><GridItem
              imageUrl="https://d15gvnltmubede.cloudfront.net/The-kurious/SERVICES-IMAGES/podcast-audio.jpg"
              text="Podcasting"
              text2="/audio"
            />
            </Link>
           {/* <Link href="/branding"><GridItem
              imageUrl="https://d15gvnltmubede.cloudfront.net/The-kurious/SERVICES-IMAGES/branding-epks.png"
              text="branding"
              text2="/epks"
            />
            </Link>  */}
            <Link href="/immersive-tech">
            <GridItem
              imageUrl="https://d15gvnltmubede.cloudfront.net/The-kurious/SERVICES-IMAGES/immersive-tech.png"
              text="Immersive Tech"
              text2=""
            />
            </Link>
            <Link href="/marketing-content">
            <GridItem
              imageUrl="https://d15gvnltmubede.cloudfront.net/The-kurious/SERVICES-IMAGES/merketing-content.png"
              text="marketing"
              text2="content"
            />
            </Link>
        
          

    </div>

</div> 

    </main>
  );
};

export default Services;
