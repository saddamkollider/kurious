import MonthlyCalendar from '@/components/calander';
import type { FC } from 'react';

interface BookingsProps {}

const Bookings: FC<BookingsProps> = () => {
    return (
        <main className='max-w-7xl mx-auto mt-32'>
        <MonthlyCalendar />

     
        </main>
    );
}

export default Bookings;
