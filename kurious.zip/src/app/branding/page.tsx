'use client'
import React, { FC, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { BiLogoInstagram, BiLogoTiktok } from "react-icons/bi";
import { FaFacebookF } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FiPhoneCall } from "react-icons/fi";
import ProductArticle from "@/components/ui/ProductionArticle";


interface CreatorsProps { }

const Creators: FC<CreatorsProps> = () => {

  return (
    <main className="mx-10">
     
      <Banner />
      <section className="max-w-8xl mx-auto my-5 text-lg ">
      
          <ProductArticle paragraph="Unlock the potential of your brand with our comprehensive branding solution" heading="Our Creative Agency includes members for all film related activities." />

        <div className="grid mx-auto lg:grid-rows-2 lg:grid-cols-2 gap-3  mt-5">
          <div className="row-span-2 h-full">
            {/* short$featured film video */}
          <VideoHoverCard 
          videoUrl={"/assets/branding/"} 
          imgUrl={"/assets/branding/branding06.png"}
          title="Branding"/>
          </div>
                {/* documentory video */}
          <VideoHoverCard 
          videoUrl={"/assets/branding/Hydro-Webbanner-Highres.mp4"} 
          imgUrl={"/assets/branding/Branding01.png"}
          title="Branding "/>
          {/* Animations video */}
          <VideoHoverCard 
          videoUrl={"/assets/branding/Hydro-Webbanner-Highres.mp4"} 
          imgUrl={"/assets/branding/branding04.png"}
          title="Product Branding"/>
       
        </div>
      </section>
    </main>
  );
};

export default Creators;

const Banner = () => {
  return (<>

    <div className="lg:w-full lg:h-[32vh] h-[10vh]   bg-[#2a2a2a] mt-5 flex items-center">
      <article className="uppercase text-2xl lg:text-5xl font-bold  mx-auto  ">
        <p className="border-b-4 text-white w-fit tracking-wide leading-snug border-yellow-300">
          Branding/EPK
        </p>
      </article>
    </div>
  </>)
}

interface VideoHoverCardProps{
  videoUrl:string;
  imgUrl:string;
  title: string;
}

const VideoHoverCard : React.FC<VideoHoverCardProps>=({videoUrl,imgUrl,title}) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleHover = () => {
    setIsHovered(true);
  };

  const handleLeave = () => {
    setIsHovered(false);
  };

  return (

    <div
    className={`relative group h-full overflow-hidden ${isHovered ? 'hovered' : ''}`}
    onMouseEnter={handleHover}
    onMouseLeave={handleLeave}
  >
    <div className="bg-white border w-full border-gray-200 h-full shadow relative overflow-hidden">
      
        <div className="absolute w-full h-full transition-transform duration-300 transform group-hover:scale-10 object-cover rounded-lg flex top-2 left-5 text-white z-10">
          <p className="text-lg text-white font-bold lg:text-4xl">{title}</p>
        </div>
      
      <img
        className="object-cover w-full h-full transition-transform duration-300 transform group-hover:scale-105"
        src={imgUrl} // Replace with your image URL
        alt="img"
      />
      {isHovered && (
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover rounded-lg"
          controlsList="nodownload"
        >
          <source
            src={videoUrl} // Replace with your video URL
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      )}
    </div>
  </div>
  );
};

