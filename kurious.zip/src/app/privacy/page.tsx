"use client"

import Image from "next/image";
import type { FC } from "react";

import "react-responsive-carousel/lib/styles/carousel.min.css"; 

interface PrivacyProps {}

const Privacy: FC<PrivacyProps> = () => {
  return (
    <main className="px-10">

            <div className= "lg:mt-10 mt-5 text-justify">
            
                <h1 className="font-bold mb-4"> Who we are</h1>

                <p className='mb-2 lg:mb-2'> The Kollider Group is a group of companies comprising:</p>

                <p className='mb-2 lg:mb-2'> Kollider Incubator Limited (CRN 12741177), registered office Level 3, Castle House, Castle Street,, Sheffield, South Yorkshire, United Kingdom, S3 </p>

                <p className='mb-2 lg:mb-2'>Kurious Arts Limited (CRN 12140186), registered office Level 3, Castle House, Castle Street,, Sheffield, South Yorkshire, United Kingdom, S3 (each a Kollider Company, together Kollider Group, we, our and us) </p>
                <p className='mb-2 lg:mb-2'>  (each a <span className="font-bold">Kollider Company,</span> together <span className="font-bold"> Kollider Group, we, our</span> and  <span className="font-bold">us</span> )</p>

                <p className='mb-2 lg:mb-2'> Further companies may be added to the Kollider Group over time.</p>

                <p className='mb-2 lg:mb-2'> The Kollider Group is committed to protecting the privacy and security of your personal data, in accordance with Regulation (EU) 2016/679 of the European Parliament and of the Council of 27 April 2016 on the protection of natural persons with regard to the processing of personal data and on the free movement of such data (GDPR) and any applicable national legislation implementing the GDPR or otherwise related to the processing of personal data, as may be amended or replaced from time to time <span className="font-bold"> (Data Protection Legislation)</span>.</p>

                <p className='mb-2 lg:mb-2'>Personal data means any information about an individual from which that person can be identified. It does not include anonymous data from which you cannot be identified.</p>

                <p className='mb-2 lg:mb-2'> An organisation responsible for deciding how your personal data is held and used is called a ‘data controller’ by the Data Protection Legislation. Within the Kollider Group the Kollider Company performing this role will vary depending on your relationship with the Kollider Group (and will typically be the first Kollider Company with which you had a relevant relationship).</p>

                <p className='mb-2 lg:mb-2'> We will only use your personal data when the law allows us to and we have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorised way, altered or disclosed.</p>

                <p className='mb-2 lg:mb-2 font-bold'>  How is your personal information collected?</p>

                <p className='mb-2 lg:mb-2'>We collect personal data through our interactions with you, when you avail of our services or purchase our products and when you complete our administrative forms in hard copy or on-line for our services and products.</p>

                <p className='mb-2 lg:mb-2 font-bold'>We use different methods to collect data from and about you including through:</p>

                <p className='mb-2 lg:mb-2'>Direct interactions – you may give us your identity and contact data by filling in forms, using a Kollider Company website or application, uploading personal details to a profile page held on a Kollider Company online platform or by corresponding with us by post, phone, email or otherwise;</p>

                <p className='mb-2 lg:mb-2'>Automated technologies or interactions – as you interact with our website and digital platforms, we may automatically collect technical data about your equipment, browsing actions and patterns, and we collect this personal data by using cookies, server logs and other similar technologies (please see our Cookies Policy for further details); and</p>

                <p className='mb-2 lg:mb-2'>Third parties or publicly available sources – we may receive personal data about you from various third parties and public sources.</p>

                <p className='mb-2 lg:mb-2 font-bold'> What kind of personal information will be collected</p>

                <p className='mb-2 lg:mb-2'> The personal information collected may include: name, address, email and other contact details, financial details, education and work history, transaction history and viewing preferences, website browsing history and a number of personal preferences.</p>

                <p className='mb-2 lg:mb-2 font-bold'>How we use your personal information</p>

                <p className='mb-2 lg:mb-2'> We will only use your personal data when the law allows us to.</p>

                <p className='mb-2 lg:mb-2'>In order to deliver, personalise and improve our services, we combine and use the information that we have about you (including information we receive through your use of our services) to understand how you use and interact with our services and the people or things that you’re connected to and interested in. We may also use the information we have about you in the following ways and for the following purposes:</p>
                <ul className='mb-2 lg:mb-2 lg:ml-5'>
                            <li> To provide, maintain, improve and develop relevant features, content and services;</li>
                            <li> To fulfil your requests and when authorised by you;</li>
                            <li> To help advertisers and publishers connect to offer relevant advertising in their apps and websites;</li>
                            <li> To match and serve targeted advertising (across devices and both on and off our services);</li>
                            <li> To contact you with information about your account or with marketing messages;</li>
                            <li> To associate your activity across our services and your different devices, for which we may associate activity and accounts under a single user ID;</li>
                            <li> To carry out or support promotions;</li>
                            <li> To conduct research and support innovation;</li>
                            <li> To create analytics and reports for external parties, including partners, publishers, advertisers, apps, and the public regarding the use of and trends within our services and ads, including showing trends to partners regarding general preferences, the effectiveness of ads and information on user experiences;</li>
                            <li> To provide location-based services, advertising, search results and other content consistent with your location settings;.</li>
                            <li> To combine information that we have about you with information that we obtain from business partners or other companies, such as your activities on other sites and apps in order to ensure that the ads, services and content we provide to you are suited to your interests; and</li>
                            <li> To detect and defend against fraudulent, abusive or unlawful activity and to keep our services safe and secure.</li>
                            </ul>
          <p className='mb-2 lg:mb-2 font-bold'> How we share this information</p>

          <p className='mb-2 lg:mb-2'> Kollider Companies share information with other Kollider Companies. We also share information that we have about you in accordance with this Privacy Policy, including to provide services that you have requested. We do not sell, license or share information that individually identifies our customers with companies, organisations or individuals outside of the Kollider Group unless one of the following circumstances applies:</p>

          <p className='mb-2 lg:mb-2'>  with your consent – we will share information with companies, organisations or individuals outside of the Kollider Group with your consent;</p>

          <p className='mb-2 lg:mb-2'> for legal purposes – we may access, preserve and disclose information to investigate, prevent or take action in connection with: (i) legal processes, and legal and governmental agency requests; (ii) enforcement of any terms and conditions relating to your use or purchase of any Kollider Company’s goods or services (including any websites or other platforms), ; (iii) claims that any content violates the rights of third parties; (iv) requests for customer service; (v) technical issues; (vi) protecting the rights, property or personal safety of a Group Company, its users or the public; (vii) establishing or exercising our legal rights or defending against legal claims; or (viii) as otherwise required by law;</p>

          <p className='mb-2 lg:mb-2 font-bold'> Information security and data retention</p>

          <p className='mb-2 lg:mb-2'> The Kollider Group has technical, administrative and physical safeguards in place to help protect against unauthorised access, use or disclosure of customer information that we collect or store.</p>

          <p className='mb-2 lg:mb-2'> The Kollider Group will retain your information only for as long as is necessary for the purposes set out in this Privacy Policy, for as long as your account with a Kollider Company is active or as needed to provide you with the relevant services. If you no longer want a Kollider Company to use your information to provide you with these services, you can close your account wtih the relevant Kollider Company unless the Kollider Group needs to retain and use your information to comply with our legal obligations, to resolve disputes or to enforce our agreements.</p>

          <p className='mb-2 lg:mb-2 font-bold'> Protecting children’s privacy</p>

          <p className='mb-2 lg:mb-2'> Our Services are for a general audience. We do not knowingly collect, use or share information that could reasonably be used to identify children under the age of 16 or as otherwise consistent with applicable law.</p>

          <p className='mb-2 lg:mb-2 font-bold' >  Data processing and transfers</p>

          <p className='mb-2 lg:mb-2'> When you use or interact with any of our services, you consent to the data processing, sharing, transferring and usage of your information as outlined in this privacy policy. Regardless of the country where you reside, you authorise us to transfer, process, store and use your information in countries other than your own in accordance with this privacy policy and to provide you with services. Some of these countries may not have the same data protection safeguards as the country where you reside.</p>

          <p className='mb-2 lg:mb-2'> The Kollider Group may process information related to individuals in the EU/EEA and may transfer that information from the EU/EEA through various compliance mechanisms, including data processing agreements based on the EU/EEA Standard Contractual Clauses. By using our services, you consent to us transferring information about you to these countries.</p>

          <p className='mb-2 lg:mb-2'> The Kollider Group is part of a global service and so shares information with affiliates and other companies based outside the European Economic Area (‘EEA’) for the purposes described in this Privacy Policy.</p>

          <p className='mb-2 lg:mb-2'> The United States and other non-EEA countries have different laws on data protection and rules in relation to government access to information. If you are based in the EEA, when your data is moved from your home country to a third country outside the EEA, some of these countries may not have the same data protection safeguards as your home country.</p>

          <p className='mb-2 lg:mb-2 font-bold'> Changes</p>

          <p className='mb-2 lg:mb-2'> We may amend or update this privacy policy from time to time, so you should check it periodically. If we make changes of a material nature, we will provide you with appropriate notice before such changes take effect.</p>

          <p className='mb-2 lg:mb-2 font-bold'>  Questions & suggestions</p>

          <p className='mb-2 lg:mb-2'>  If you have questions or suggestions relating to your information, or wish to make a complaint, please contact us at: Kollider Group, Angel Street, Sheffield, United Kingdom S3 8LN</p>
            
            </div>
    
    
    </main>
  );
};

export default Privacy;
