'use client'
import MainCard from "@/components/ui/MainCard";
import React, { FC, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { BiLogoInstagram, BiLogoTiktok } from "react-icons/bi";
import { FaFacebookF } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FiPhoneCall } from "react-icons/fi";
import SocialLink from "@/components/ui/SociMediaIcon/page";

interface GridItemProps {
  imageUrl: string;
  text: string;
  texts: string;
  url:string;
  description?: string;
}

const GridItem: FC<GridItemProps> = ({ imageUrl, text, texts, url, description }) => (
 <div>
  <div className="relative group">
    <Link href={url}>
    <div
      className="bg-cover grayscale bg-center h-[60vh] bg-no-repeat mt-5 md:mt-4 lg:mt-3"
      style={{ backgroundImage: `url(${imageUrl})` }} 
    >
      <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-40 transition duration-300"></div>
    </div>
    <div className="absolute bottom-3 ml-4 top-0 mt-2 lg:mt-2 opacity-0 group-hover:opacity-100 transition duration-300">
      <p className="text-white text-lg md:text-xl lg:text-4xl font-semibold uppercase">{text}</p>

      <p className="text-primary -mt-2 lg:mt-1 text-sm md:text-xl lg:text-sm font-semibold uppercase">{texts}</p>
      <p className="text-white whitespace-pre-line">{description}</p>
    </div>
    </Link>
  </div>
  </div>
 
);

interface CreatorsProps {}

const Creators: FC<CreatorsProps> = () => {
  const [search, setSearch] = useState('');

  const gridItems = [

    // {
    //   imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/anna.jpg",
    //   text:"Anna",
    //   texts:"Advertising",
    //   description:"",
    //   url:"#",
    // },
    {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/barbara.jpg",
      text:"barbara",
      texts:"Acting Teacher",
      description:``,
      url:"/profile/barbara",
    },
    {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/benedictprofile.png",
      text:"benedict",
      texts:"Composer",
      description:``,
      url:"/profile/benedictprofile",
    },
    {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/dalitprofilepic.png",
      text:"dalit",
      texts:"editor and director",
      description:``,
      url:"/profile/dalit",
    },
    
    {
    
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/jamesmprofilepic.png",
      text:"james",
      texts:"podcast strategist and producer",
      description:``,
      url:"/profile/jamesprofile",
    },
    
  
  {
    imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/marcusprofilepic.png",
      text:"Marcus",
      texts:"Audio Technician",
      description:``,
      url:"/profile/marcusprofile",
  },
   
  //   {
  //     imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/naomi.jpg",
  //     text:"Naomi",
  //     texts:"Photography",
  //     url:"#",
  // },
  {
    imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/ryan.png",
    text:"Ryan",
    texts:"Animator/Director",
    description:``,
      url:"/profile/ryan-profile",
},
// {
//   imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/Will.png",
//   text:"Will",
//   texts:"Member",
//   url:"#",
// },
{
  imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/Chris.png",
  text:"Chris",
  texts:"Director",
  description:``,
      url:"/profile/christ-profile",
},
    
  //    {
  //     imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/richardprofilepic.png",
  //     text:"Richard",
  //     texts:"Advertising",
  //     url:"#",
  // },
  //   {
  //     imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/thumbnail_ian.jpg",
  //     text:"Ian",
  //     texts:"Editor",
  //     url:"#",
  // },
  {
    imageUrl:"/assets/virtualmemberImages/unnamed.png",
    text:"Ben Wilkinson",
    texts:"festival director",
    description:``,
    url:"/profile/benwilkinson-profile",
   
  },
  {
    imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/JenLawton-HuntHeadshot.jpg",
    text:"Jen Lawton-Hunt",
    texts:" Actor",
    description:``,
    url:"/profile/jenlaw-profile",
   
  },
  {
    imageUrl:"/assets/virtualmemberImages/Ruben.jpeg",
    text:"Rubén Seca",
    texts:"Filmmaker",
    description:``,
    url:"profile/Ruben-Seca-Profile",
    
  },
  {
    imageUrl:"/assets/virtualmemberImages/Manuel-S.-Pita-Romero.jpg",
    text:"Manuel S Pita Romero",
    texts:"Filmmaker",
    description:``,
    url:"profile/Manuel-profile",
  },
  {
    imageUrl:"/assets/virtualmemberImages/Julen-Higuera-Lozano.jpeg",
    text:"Julen Higuera Lozano",
    texts:"Filmmaker",
    description:``,
    url:"profile/Julen-Higuera-Lozano",
  },
  {
    imageUrl:"/assets/virtualmemberImages/Eric_Layer.jpeg",
    text:"Eric Layer",
    texts:"Filmmaker / Director",
    description:``,
    url:"profile/eric-layer",
  },
  {
    imageUrl:"/assets/virtualmemberImages/Pablo-Villalobos.jpg",
    text:"Pablo Villalobos",
    texts:"Director",
    description:``,
    url:"profile/pablo-villalobos",
  },
  {
    imageUrl:"/assets/virtualmemberImages/UVFF-Kieron-Kieron-Moore.jpeg",
    text:"Kieron Moore",
    texts:"Director",
    description:``,
    url:"profile/kieron-kieron",
  },
  
  ];
 /**the filter grid items based on the search query */

  const filteredGridItems = gridItems.filter((item) =>
    item.text.toLowerCase().includes(search.toLowerCase())||
    item.texts.toLowerCase().includes(search.toLowerCase())
  );


  return (
    <main className="px-10">
      <MainCard>
  <video   
     autoPlay
     loop
     muted
     playsInline
    className="object-cover absolute h-full w-full grayscale"
    src="https://d15gvnltmubede.cloudfront.net/the-kurious-videos/collective-video.mp4"
  />

  <div className="uppercase absolute  left-4 top-2 lg:top-0 mt-3 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-[10rem] lg:font-extrabold font-bold text-left">
        <span className="tracking-tighter">join the<br/> collective</span> 
        <span className="tracking-tighter flex lg:mt-4 left-4 text-sm lg:text-[3rem]">home for creatives</span>
        </div>

</MainCard>
<SocialLink/>
<div className="mt-5">
          <input className="w-full mt-5 lg:w-auto"
            type="text"
            placeholder="Search"
            value={search}
            onChange={(e) =>{
              setSearch(e.target.value);
            }
          }                                
          /> 
          <Link href="/virtualMember">
  <button className="px-10 font-semibold py-2 text-sm md:text-lg bg-primary shadow-md w-full lg:w-auto lg:ml-5 ml-0 mt-5">
     Virtual Members
  </button>
</Link>
<Link href="/creators-nprofile">
  <button className="px-10 font-semibold py-2 text-sm md:text-lg bg-primary shadow-md w-full lg:w-auto lg:ml-5 ml-0 mt-5">
     Creators
  </button>
</Link>

    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 lg:mt-5">

                            {gridItems.map((item) => {
                                        if (item.texts.toLowerCase().includes(search.toLowerCase())||
                                            item.text.toLowerCase().includes(search.toLowerCase())) {
                                          return (
                                           
                                            <GridItem
                                              key={item.text}
                                              imageUrl={item.imageUrl}
                                              text={item.text}
                                              texts={item.texts}
                                              url={item.url}
                                              description={item.description}
                                            />
                                            
                                          );
                                        }
                                        return null; // Hide non-matching items
                                      })}
                                      
            </div>
            
    </div>
    
    <div className="w-full mt-5 ">
        <ul className="flex mb-2 md:justify-end md:gap-4 justify-between text-2xl items-center ">
          <li>
          <Link href='https://www.instagram.com/thekurious_/'>
            <BiLogoInstagram />
            </Link>
          </li>
          <li>
          <Link href='https://www.facebook.com/people/The-Kurious/100079157044792/'>
            <FaFacebookF />
            </Link>
          </li>
          <li>
          <Link href='https://twitter.com/thekurious_'>
            <FaXTwitter />
            </Link>
          </li>
          <li>
          <Link href='https://www.tiktok.com/@thekurious_'>
            <BiLogoTiktok />
            </Link>
          </li>
          <li>
          <Link href='tel:01143123659'>
            <FiPhoneCall />
            </Link>
          </li>
          <Link href="#">
            <li className="px-2 py-1 text-sm md:text-lg bg-primary rounded-lg shadow-md ">
              BOOK NOW
            </li>
          </Link>
        </ul>
      </div>

</main>
  );
};

export default Creators;
