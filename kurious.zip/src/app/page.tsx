"use client"
import MainCard from "@/components/ui/MainCard";
import Link from "next/link";
import Typewrite from "@/components/ui/TypeRight";
import Image from "next/image";
import type { FC } from "react";
import Typewriter from "typewriter-effect"
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import { Carousel } from 'react-responsive-carousel';
import {FaBackward} from 'react-icons/fa';
import {FaForward} from 'react-icons/fa';
import SocialLink from "@/components/ui/SociMediaIcon/page";

 
interface KuriousProps {}

const Kurious: FC<KuriousProps> = () => {
  return (
    <main className="px-10">

      <Carousel
        showArrows={false} showStatus={false} showThumbs={false} showIndicators={false}
        renderArrowPrev={(clickHandler) => (
          <button onClick={clickHandler} className="arrow-button absolute lg:text-5xl text-3xl z-10 top-2/4 text-primary">
            <FaBackward/>
          </button>
        )}
        renderArrowNext={(clickHandler) => (
          <button onClick={clickHandler} className="arrow-button absolute lg:text-5xl text-3xl right-2  top-2/4 text-primary">
            <FaForward/>
          </button>
        )}> 
         <MainCard>
        <video
             autoPlay
             loop
             muted
             playsInline
          className="object-cover absolute h-full w-full grayscale">
          <source src="/assets/home/KuriousHomepageVideo.mp4" type="video/mp4"/>
          {/* <source src="KURIOUS-HOM-EPAGE-VIDEO~2.mp4" type="video/webm"/> */}
          
          {/* // src="https://d15gvnltmubede.cloudfront.net/KURIOUS%20HOM%20EPAGE%20VIDEO.mp4" */}
         
          </video>
        <div className="absolute  md:left-10 top-5 left-1 text-white font-bold text-4xl  md:text-7xl lg:text-9xl">
          {/* <span>SPACE</span> */}
        </div>

        <div className="uppercase absolute bottom-5 right-5 text-primary  text-4xl md:text-7xl lg:text-9xl font-bold text-right ">
          {/* <div className="text-white"> To</div> */}
        <Typewrite wordsList={["CREATE..","EXPLORE..", "PRODUCE..","DESIGN..","RECORD..","NETWORK.."]} />
        </div>
            </MainCard>
            <MainCard>
              <img
                className="object-cover h-full w-full"
                src="/assets/agency.png"
                alt="image"
              />
              <div className="absolute
              lg:grid items-end
              text-left  md:bottom-0 md:left-10 top-1 lg:top-5 left-1 text-white lg:-ml-5 font-bold text-4xl md:text-7xl lg:text-[12rem] lg:pb-0">
                  <div className="">
                  <span>THE</span><br/>
                  <span>AGENCY</span>
                  </div>
              </div>

              <div className="uppercase   absolute bottom-5 right-5 text-white text-right z-50 ">
                <ul>
                  <Link href="/services"><li className="hover:text-primary cursor-pointer hover:font-semibold">
                    service
                  </li></Link>
                  <Link href="/creators">
                  <li className="hover:text-primary cursor-pointer hover:font-semibold">
                    creators
                  </li>
                  </Link>
                  <Link href="/membership">
                    <li className="hover:text-primary cursor-pointer hover:font-semibold">
                    membership
                  </li>
                  </Link>
                  <Link href="https://theallstoreonline.co.uk/">
                    <li className="hover:text-primary cursor-pointer hover:font-semibold">
                    allfilm
                  </li>
                  </Link>
                </ul>
              </div>
            </MainCard>
            <MainCard>
              <img
                className="object-cover h-full w-full"
                src="/assets/elevate2.jpg"
                alt="image"
              />
              <div className="absolute  md:left-10 top-5 left-1 text-white font-bold text-4xl  md:text-7xl lg:text-9xl">
                <span>ELEVATE</span>
              </div>

              <div className="uppercase  absolute bottom-5 right-5 text-white text-4xl md:text-7xl lg:text-9xl font-bold text-right ">
                <span>
                  YOUR <br />
                  CREATIVE <br /> CAREER
                </span>
              </div>
            </MainCard>
      </Carousel>
      <SocialLink />
    </main>
  );
};

export default Kurious;
