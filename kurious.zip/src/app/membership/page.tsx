"use client";
import MainCard from "@/components/ui/MainCard";
import type { FC } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import VideoModal from "@/components/ui/VidoModel";
import React, { useState, useEffect } from "react";
import CompanyLogos from "@/components/memberslogo/memberlogo";

import SocialLink from "@/components/ui/SociMediaIcon/page";

interface TheMembershipProps {}

interface Review {
  id: number;
  name: string;
  comment: string;
}

const reviews: Review[] = [
  {
    id: 1,
    name: "Ed Swales",
    comment:
      "There is a welcoming and mutually supportive ethos at The Kurious which makes it an ideal base for anyone working in a creative job. The variety of skills across the current membership has led me to many fulfilling collaborations and new partnerships. A great place to work!",
  },
  {
    id: 2,
    name: "Hugh Mann Adamson",
    comment:
      "What an incredible place to work, network, collaborate and create! The best thing our production company ever did was moving to The Kurious! Can't recommend it highly enough!",
  },
  {
    id: 3,
    name: "Anastasia Yules",
    comment:
      "The Kurious has some of the best post-production facilities and co-working space, and is filled with talented professionals in the industry. It's located within the city centre, which makes it so logistically convenient for the productions and/or the people who work there.",
  },
  {
    id: 4,
    name: "Ian Champion",
    comment:
      "As an actor employed by Enon Films' team at the Kurious as well as being a friend of the venue, it is a marvelous and special hub. Kurious's facilities and creatives are always buzzing with ambition and a friendly welcome. Highly recommended.",
  },
  {
    id: 5,
    name: "Gabriel Fernández-Gil",
    comment:
      "The best for hire post-production facilities in the area, literally! Amazing locations too and great co-working space filled with fantastic professionals and opportunities.",
  },
  {
    id: 6,
    name: "Charlotte Prescott",
    comment:
      "Kurious have been great at letting us hire their sound recording studio, especially at late notice. Ryan is wonderful and makes sure everything is ready for you on the day.",
  },
  {
    id: 7,
    name: "J Clark",
    comment:
      "Best working space I've been, creative relaxed environment, amazing post/design facilities and....it has a bar, ping pong table, food discount and arcade machines, what more can you want🤘.",
  },
  {
    id: 8,
    name: "Toby Watts",
    comment:
      "A great resource as a filmmaker for networking, film events and post production facilities. A huge asset to Sheffield.",
  },
  {
    id: 9,
    name: "MO Owolabi",
    comment:
      "It is always a great time working at The Kurious, you would usually feel relaxed while you are working because the people are great and the ambience is fantastic.",
  },
  {
    id: 10,
    name: " Ian Waters",
    comment:
      "A wonderful creative melting pot filled with lovely friendly people. I can't recommend it enough!",
  },
  {
    id: 11,
    name: "John-Patrick Quinn",
    comment:
      "Great collaborative workspace for creatives in the heart of Sheffield.",
  },
  {
    id: 12,
    name: "Mat Pennell",
    comment: "Fantastic. Helpful. Perfect",
  },
  {
    id: 13,
    name: "Bixpit Studio",
    comment: "A brilliant space filled with brilliant filmmakers",
  },
  // Add more reviews here
];

const GridItem = ({
  imageUrl,
  text,
  text2,
  content,
  
}: {
  imageUrl: string;
  text: string;
  text2: string;
  content:string;
  
}) => (
  <div className="relative group">
    <div
      className="bg-cover h-64 md:h-72 lg:h-[50vh] bg-no-repeat"
      style={{ backgroundImage: `url(${imageUrl})` }}
    >
      <div className="absolute inset-0 bg-gray-500 opacity-0 group-hover:opacity-100 transition duration-300">
        <ul className="list-disc lg:pt-24 text-[0.7rem] p-4 lg:text-[1rem] lg:pl-10 lg:pr-10 text-white lg:top-40 pt-16 pl-8">
          {content.split(';').map((item,index)=>(
            <li key={index}>{item.trim()}</li>
          ))}</ul></div>
    </div>
    <div className="absolute top-0 mt-3 ml-4 text-left">
      <p className="text-white text-lg md:text-xl lg:text-4xl font-semibold uppercase">
        {text}
      </p>
      <p className="text-white -mt-2 text-lg md:text-xl lg:text-4xl font-semibold uppercase">
        {text2}
      </p>
    </div>
  </div>
);

const TheMembership: FC<TheMembershipProps> = () => {
  const [currentReviewIndex, setCurrentReviewIndex] = React.useState(0);

  const nextReview = () => {
    setCurrentReviewIndex((prevIndex) =>
      prevIndex === reviews.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevReview = () => {
    setCurrentReviewIndex((prevIndex) =>
      prevIndex === 0 ? reviews.length - 1 : prevIndex - 1
    );
  };

  useEffect(() => {
    const interval = setInterval(nextReview, 3000); // Change the interval duration as needed
    return () => clearInterval(interval);
  }, []);

  const [videoSource, setVideoSource] = useState<string>("");
  const [isVideoVisible, setIsVideoVisible] = useState<boolean>(false);

  const playVideo = (source: string) => {
    setVideoSource(source);
    setIsVideoVisible(true);
  };

  const closeVideo = () => {
    setIsVideoVisible(false);
  };

  return (
    <main className="px-10">
      <MainCard>
        <img
          className=" absolute object-cover object-right-top h-full w-full"
          src="/assets/membership/testomonialimage.png"
          alt="Allfilm"
        />

       <div className=" absolute text-white  max-w-6xl bottom-20 left-2 text-left md:top-5 md:left-5">
          {/* <span className="italic"> &quot;The Kurious is a great creative space located in the centre of Sheffield.The access to high-end editing suites has been immensely helpful for the start to smooth production. The supply of peppermint tea is excellent, as well as the very tempting array of eateries just downstairs in Kommune&quot; <span className="inline-block font-semibold capitalize text-yellow-300 not-italic">- abi timins, filmmaker</span></span> */}
          
        </div>
          

  {/* <div className="uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left"> */}

        <div className="uppercase absolute tracking-tighter bottom-5 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold">
          {/* <div className="uppercase absolute top-2 lg:mt-3 left-4 lg:left-8 md:left-5 text-white  text-4xl md:text-6xl lg:text-9xl font-bold text-left"> */}

          <span>Memberships</span>
        </div>
      </MainCard>
      <SocialLink/>
      <div>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 lg:mt-5">
          <GridItem
            imageUrl="/assets/Jon-Addison.jpeg"
            text="virtual"
            text2="membership"
            content="Access to film-funding, co-production and production and post-production equity;
                      25% discount on the recording and edit suite;
                      Work opportunities from Kurious co-produdctions;
                      Showcase your work via the Kurious website and socials;
                      Events and socials;
                      Showcase your work on AllFilm"
            
          />

          <GridItem
            imageUrl="https://d15gvnltmubede.cloudfront.net/creators-pictures/anna.jpg"
            text="full"
            text2="membership"
            content=" All benefits of remote membership plus;
                      Unlimited days on site;
                      Four days access to the recording and edit suite and a further 60% discount for additional use;
                      Access to a meeting room;
                      Free access to events and socials such as Kurious film night and Kurious network live;
                      Gym, hotel and parking discounts. Including NCP at 60% off;
                      Up to 15% discount on Kommune
            "
          />
          <GridItem
            imageUrl="/assets/office3.jpg"
            text="private"
            text2="office space"
            content="Cool office space for a team of 2/4/6/8 with a pool table, bar, tea/coffee refreshments;
                      Access to a meeting room;
                      Gym, hotel and parking discounts. Including NCP at 60% off;
                      Up to 15% discount on Kommune"/>
        </div>
      </div>
      <div>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 text-left lg:text-center lg:mt-10 mt-5 lg:text-[1.5rem]">
          <div className="grid-item hover:text-gray-400">
            <button
              className=" uppercase border-4 w-full border-gray-500"
              onClick={() =>
                playVideo(
                  "https://d15gvnltmubede.cloudfront.net/the-kurious-videos/testimonial-video/dalit-testomonial-full-website.mp4"
                )
              }
            >
              video testimonial-Dalit
            </button>
          </div>
          <div className="grid-item hover:text-gray-400">
            <button
              className="uppercase border-4 w-full border-gray-500"
              onClick={() =>
                playVideo(
                  "https://d15gvnltmubede.cloudfront.net/the-kurious-videos/testimonial-video/marcus-testomonial-full.mp4"
                )
              }
            >
              video testimonial-marcus
            </button>
          </div>
          <div className="grid-item hover:text-gray-400">
            <button
              className="uppercase border-4 w-full  border-gray-500"
              onClick={() =>
                playVideo(
                  "https://d15gvnltmubede.cloudfront.net/the-kurious-videos/testimonial-video/gabbytestomonial-full-website.mp4"
                )
              }
            >
              video testimonial-gabby
            </button>
          </div>
        </div>
        {isVideoVisible && (
          <VideoModal source={videoSource} onClose={closeVideo} />
        )}
      </div>

      <div className="">
        <p className="uppercase text-center mt-5 text-3xl font-semibold lg:text-5xl lg:mt-10">
          What our clients say
        </p>
      </div>

      <div className="max-w-7xl mx-auto">
        <figure className="relative">
      
      <img
            className=""
            src="/pictures/review.png"
            alt="Review Screen"
            />
              <div className="absolute z-10 top-[20%] md:top-[20%] max-w-[75%] left-1/2 -translate-x-1/2">
                <p className=" lg:text-center lg:text-[1.5rem] md:text-[0.8rem] text-[0.4rem]">
                  {reviews[currentReviewIndex].comment}
                </p>
                <p className="text-center text-[0.5rem] lg:text-[1rem] mt-2 font-bold">
                  - {reviews[currentReviewIndex].name}
                </p>
              </div>
            </figure>
      </div>

      <div>
        <div className="font-bold text-lg md:text-2xl lg:text-3xl mt-32 mb-5 md:mt-6 ml-5 md:ml-10 mr-5 md:mr-10">
          {" "}
          Why join us?{" "}
        </div>
        <CompanyLogos />
      </div>
    </main>
  );
};

export default TheMembership;
