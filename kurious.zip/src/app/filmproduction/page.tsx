'use client'
import React, { FC, useState } from "react";
import ProductArticle from "@/components/ui/ProductionArticle";


interface CreatorsProps { }

const Creators: FC<CreatorsProps> = () => {

  return (
    <main className="mx-10">
      <Banner/>
      <section className="max-w-8xl mx-auto my-5 text-lg ">
    
          <ProductArticle paragraph="Our Creative Agency are award-winning Producers, Directors, Videographers, Animators and Technicians. Delivering short films, music video&#39;s and feature films with cinematic experiences, with immersive characters, themes, ploys and storytelling.  Or Documenataties, employing a mix of interviews, archive footage, narration, and observational footage to document a factual and enlightening account" heading=" Our Creative Agency includes members for all film related activities." />

        <div className="grid mx-auto lg:grid-rows-2 lg:grid-cols-2 gap-3  mt-5">
          <div className="row-span-2 h-full">
            {/* short$featured film video */}
          <VideoHoverCard 
          videoUrl={"/assets/filmproduction-contents/KURIOUS-GRADING-REEL.mp4"} 
          imgUrl={"/assets/filmproduction-contents/short&Featured-films.png"}
          title="Short & Featured Film"/>
          </div>
                {/* documentory video */}
          <VideoHoverCard 
          videoUrl={"/assets/filmproduction-contents/"} 
          imgUrl={"/assets/filmproduction-contents/dcumentory.png"}
          title="Documentary"/>
          {/* Animations video */}
          <VideoHoverCard 
          videoUrl={"/assets/filmproduction-contents/KURIOUS-ANIMATION-REEL.mp4"} 
          imgUrl={"/assets/filmproduction-contents/animations.png"}
          title="Animation"/>
       
        </div>

        <div className="grid mx-auto lg:grid-rows-2 lg:grid-cols-2 gap-3  mt-5">
        
            {/* Podcasting video */}
                
                {/* commercial video */}
          <VideoHoverCard 
          videoUrl={"/assets/filmproduction-contents/"} 
          imgUrl={"/assets/filmproduction-contents/Commercials.png"}
          title="Commercial"/>
          {/* musical video */}
          <VideoHoverCard 
          videoUrl={"/assets/filmproduction-contents/KURIOUS-MUSIC-VIDEO-REEL.mp4"} 
          imgUrl={"/assets/filmproduction-contents/music.png"}
          title="Music Video"/>
          {/* corporate video */}
           <VideoHoverCard 
          videoUrl={"/assets/filmproduction-contents/KURIOUS-CORPORATE-REEL.mp4"} 
          imgUrl={"/assets/filmproduction-contents/corporate.png"}
          title="Corporate Video"/>


        </div>
      </section>
    </main>
  );
};

export default Creators;

const Banner = () => {
  return (<>

    <div className=" lg:w-full lg:h-[32vh] h-[10vh] bg-[#2a2a2a] mt-5 flex items-center">
      <article className="uppercase text-2xl lg:text-5xl font-bold  mx-auto  ">
        <p className="border-b-4 text-white w-fit tracking-wide leading-snug border-yellow-300">
          Film Production
        </p>
      </article>
    </div>
  </>)
}

interface VideoHoverCardProps{
  videoUrl:string;
  imgUrl:string;
  title: string;
}

const VideoHoverCard : React.FC<VideoHoverCardProps>=({videoUrl,imgUrl,title}) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleHover = () => {
    setIsHovered(true);
  };

  const handleLeave = () => {
    setIsHovered(false);
  };

  return (
   
    <div
    className={`relative group h-full overflow-hidden ${isHovered ? 'hovered' : ''}`}
    onMouseEnter={handleHover}
    onMouseLeave={handleLeave}
  >
    <div className="bg-white border w-full border-gray-200 h-full shadow relative overflow-hidden">
      
        <div className="absolute w-full h-full transition-transform duration-300 transform group-hover:scale-10 object-cover rounded-lg flex top-2 left-5 text-white z-10">
          <p className="text-lg text-white font-bold lg:text-4xl">{title}</p>
        </div>
      
      <img
        className="object-cover w-full h-full transition-transform duration-300 transform group-hover:scale-105"
        src={imgUrl} // Replace with your image URL
        alt="img"
      />
      {isHovered && (
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover rounded-lg"
          controlsList="nodownload"
        >
          <source
            src={videoUrl} // Replace with your video URL
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      )}
    </div>
  </div>
  );
};

