"use client"

import type { FC } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import React, { useState } from 'react';
import Link from "next/link";
import {BiCameraMovie} from 'react-icons/bi';
import { FaFacebook } from "react-icons/fa6";
import { BiLogoInstagramAlt } from "react-icons/bi";
import { RiTwitterXFill } from "react-icons/ri";
import { FaTiktok } from "react-icons/fa6";
import { MdContactMail } from "react-icons/md";
interface ProfileProps {}


const Profile: FC<ProfileProps> = () => {

                              /*the toggle function for the profile content*/

           const [isFullContent, setIsFullContent] = useState(false);
                    
           const toggleContent = () => {
             setIsFullContent(!isFullContent);
           };
           const fullContent = `Mel is a self -taught filmmaker with over 15 years’ experience producing short films and showing them at festivals around the world. She is passionate about sharing the filmmaking process and supporting new filmmakers to realise their potential. ‘Seepers: A Love Story’ is her first feature film, her second feature, ‘They Fuck Y@u Up’ is currently in production.`;

  return (
    <main className="ml-[5%] md:mt-2 xl:mt-2 mt-5 lg:mt-7  mr-[5%] lg:ml-[2.5%] lg:mr-[2.5%] xl:ml-[3%] xl:mr-[3%] h-full lg:h-full">

            <div className=''>
                  <div className="flex flex-col">
                                  <div className="grid lg:grid-cols-6 grid-cols-1 lg:mt-5 gap-0 flex-1 bg-white" >
                                    <div className="bg-[#ffd831]">
                                    <img className="grayscale" src="/assets/virtualmemberImages/Melanie-Gourlay-Director.jpg" alt="Liam-Regan-Profile-image"/>
                                     
<div className=" mt-10 flex flex-col items-center justify-center">
                                  <ul className="space-y-2">
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white cursor-pointer"
                                      >
                                        <FaFacebook className="lg:text-4xl md:text-3xl" />
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        <BiLogoInstagramAlt className="lg:text-4xl md:text-3xl"  />
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                       <RiTwitterXFill className="lg:text-4xl md:text-3xl" />
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        <FaTiktok className="lg:text-4xl md:text-3xl" />
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="/contact-us"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        <MdContactMail  className="lg:text-4xl md:text-3xl"/>
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    
                                  </ul>
                                </div>

                                    </div>
                                                      <div className="col-span-5 bg-white">
                                                      <h1 className="flex lg:text-3xl text-2xl font-bold mt-0 lg:ml-16">Melanie Gourlay</h1>
                                                        <h1 className='text-left font-extralight text-2xl lg:ml-16 ml-0 mt-3'>Filmmaker</h1>
                                                        <div className=" text-justify mx-auto max-w-screen-md md:max-w-screen-md p-1 lg:max-w-screen-xl xl:max-w-screen-2xl lg:pl-16 lg:pr-16">
                                                                            {isFullContent ? (
                                                                              <div className="mb-2">
                                                                                {fullContent.split('\n').map((paragraph, index) => (
                                                                                  <p key={index} className="my-2">{paragraph}</p>
                                                                                ))}
                                                                              </div>
                                                                            ) : (
                                                                              <div className="mb-2">
                                                                                {fullContent.slice(0, 300).split('\n').map((paragraph, index) => (
                                                                                  <p key={index} className="my-2">{paragraph}</p>
                                                                                ))}
                                                                              </div>
                                                                            )}
                                                                            {isFullContent ? (
                                                                              <button onClick={toggleContent} className="text-blue-500 hover:underline">
                                                                                Read Less
                                                                              </button>
                                                                            ) : (
                                                                              <button onClick={toggleContent} className="text-blue-500 hover:underline">
                                                                                Read More
                                                                              </button>
                                                                            )}
                                                                          </div>



                                                                        <div className="grid lg:grid-cols-4 grid-cols-1 lg:gap-10 gap-0 mt-1 lg:mt-5">
                                                                          <div className="grid col-span-3 lg:ml-16   mb-4 ">
                                                                            <video autoPlay loop muted controls className='w-full'>
                                                                              <source src="https://d15gvnltmubede.cloudfront.net/the-kurious-videos/Marcus-profile-video.mp4" type="video/mp4" />
                                                                            </video>
                                                                          </div>                                                                
                                                                          <div className="">
                                                                            <div className='text-4xl font-bold'>What I do?</div>
                                                                            <div className='grid grid-cols-3 lg:grid-cols-3 md:grid-cols-3 mt-5'>

                                                                          <div className="flex flex-col md:items-center">
                                                                          <div className="mb-14 md:mb-5 lg:mb-9">
                                                                          <BiCameraMovie className="text-6xl" />
                                                                        </div>
                                                                          <div className="mb-10 md:mb-5 lg:mb-9">
                                                                            <BiCameraMovie className="text-6xl" />
                                                                            </div>
                                                                                <div className="mb-10 md:mb-5 lg:mb-9">
                                                                              <BiCameraMovie className="text-6xl" />
                                                                              </div>
                                                                                    </div>
                                                                            <div className='col-span-2'>
                                                                            <div className='mb-8 mt-1'>
                                                                              <h1 className='font-bold'>What do I DO</h1>
                                                                              <p className='font-sans w-full justify-normal'>C...</p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10 mt-0'>
                                                                              <h1 className='font-bold'>Awards & Credits</h1>
                                                                              <p>C... </p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10'>
                                                                              <h1 className='font-bold'>Some other awards</h1>
                                                                              <p>C...</p>
                                                                              </div>
                                                                            </div>

                                                                            </div>
                                                                          
                                                                          </div>
                                                                          
                                                                        </div>
                                                      </div>
                                  </div>
                  </div>
    </div>
                
    </main>
  );
};

export default Profile;




