"use client"
import MainCard from "@/components/ui/MainCard";
import Typewrite from "@/components/ui/TypeRight";
import type { FC } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import React, { useState } from 'react';
import {BiCameraMovie} from 'react-icons/bi';
interface ProfileProps {}



 
const Profile: FC<ProfileProps> = () => {
  return (
    <main className="ml-[5%] md:mt-2 xl:mt-2 mt-5 lg:mt-7  mr-[5%] lg:ml-[2.5%] lg:mr-[2.5%] xl:ml-[3%] xl:mr-[3%] h-full lg:h-full">

            <div className=''>
                  <div className="flex flex-col">
                                  <div className="grid lg:grid-cols-6 grid-cols-1 lg:mt-5 gap-0 flex-1 bg-white" >
                                    <div className="bg-[#ffd831]">
                                      <img src="https://d15gvnltmubede.cloudfront.net/creators-pictures/andre.jpg" alt="Profileimage"/>

                                      <div className=" mt-10 flex flex-col items-center justify-center">
                                  <ul className="space-y-2">
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white cursor-pointer"
                                      >
                                        Home
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        About Me
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Resume
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Portfolio
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Testimonials
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                    <li className="relative">
                                      <a
                                        href="#"
                                        className=" text-xl font-bold block px-4 py-2 hover:text-white  cursor-pointer"
                                      >
                                        Contact
                                      </a>
                                      <div className="absolute top-0 left-0 w-1   transform -translate-x-1/2"></div>
                                    </li>
                                  </ul>
                                </div>


                                    </div>
                                                      <div className="col-span-5 bg-white">
                                                        <h1 className="flex lg:text-6xl text-2xl items-center font-bold justify-center border-4 border-[#a3aea9] mt-5 lg:ml-16 mr-5 h-20">ABOUT ME</h1>
                                                        <h1 className='text-left font-extralight text-3xl lg:ml-16 ml-0 mt-5'> I am <strong>Ryan,</strong> A Writer, Director, Producer</h1>
                                                        <p className="flex lg:m-5  text-justify text-1xl lg:ml-16">I am currently freelancing as a writer, director, and animator. I have just finished
                                                              solo-animating my highly ambitious debut feature film Absolute Denial; a behemoth of a project
                                                              requiring over 30,000 frames of hand-drawn animation. The film is based on my acclaimed script EXE a quarter-finalist screenplay at the Austin Film Festival and a semi-finalist of Write LA 2018.
                                                            </p>

                                                                        <div className="grid lg:grid-cols-4 grid-cols-1 lg:gap-10 gap-0 mt-1 lg:mt-10">
                                                                          <div className="grid col-span-3 lg:ml-16   mb-4 ">
                                                                            <video autoPlay loop muted controls className='w-full'>
                                                                              <source src="Ryan-AD_TRAILER_FOR_KURIOUS_WEB.mp4" type="video/mp4" />
                                                                            </video>
                                                                          </div>
                                                                          <div className="">
                                                                            <div className='text-4xl font-bold'>What I do?</div>
                                                                            <div className='grid grid-cols-3 lg:grid-cols-3 md:grid-cols-3 mt-5'>

                                                                          <div className="flex flex-col md:items-center">
                                                                          <div className="mb-14 md:mb-5 lg:mb-9">
                                                                          <BiCameraMovie className="text-6xl" />
                                                                        </div>
                                                                          <div className="mb-10 md:mb-5 lg:mb-9">
                                                                            <BiCameraMovie className="text-6xl" />
                                                                            </div>
                                                                                <div className="mb-10 md:mb-5 lg:mb-9">
                                                                              <BiCameraMovie className="text-6xl" />
                                                                              </div>
                                                                              <div className="mb-10 md:mb-5 lg:mb-9">
                                                                              <BiCameraMovie className="text-6xl" />
                                                                              </div>
                                                                              <div className="mb-10 md:mb-5 lg:mb-9">
                                                                              <BiCameraMovie className="text-6xl" />
                                                                              </div>
                                                                                    </div>
                                                                            <div className='col-span-2'>
                                                                            <div className='mb-8 mt-1'>
                                                                              <h1 className='font-bold'>What do I DO</h1>
                                                                              <p className='font-sans w-full justify-normal'>the information comether At 18 he was 
                                                                                </p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10 mt-0'>
                                                                              <h1 className='font-bold'>Awards & Credits</h1>
                                                                              <p>the information comether </p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10'>
                                                                              <h1 className='font-bold'>Some other awards</h1>
                                                                              <p>the information comether </p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10'>
                                                                              <h1 className='font-bold'>Some other awards</h1>
                                                                              <p>the information comether </p>
                                                                              </div>
                                                                              <div className='mb-8 lg:mt-10'>
                                                                              <h1 className='font-bold'>Some other awards</h1>
                                                                              <p>the information comether </p>
                                                                              </div>
                                                                            </div>

                                                                            </div>
                                                                          
                                                                          </div>
                                                                          
                                                                        </div>
                                                      </div>
                                  </div>
                  </div>
    </div>
    

                
    </main>
  );
};

export default Profile;