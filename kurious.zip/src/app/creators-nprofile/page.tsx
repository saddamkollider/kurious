'use client'
import React, { FC, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { BiLogoInstagram, BiLogoTiktok } from "react-icons/bi";
import { FaFacebookF } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FiPhoneCall } from "react-icons/fi";

interface GridItemProps {
  imageUrl: string;
  text: string;
  texts: string;
  url:string;
  description?: string;
}

const GridItem: FC<GridItemProps> = ({ imageUrl, text, texts, url, description }) => (
 <div>
  <div className="relative group">
    {/* <Link href={url}> */}
    <div
      className="bg-cover grayscale bg-center h-[60vh] bg-no-repeat mt-5 md:mt-4 lg:mt-3"
      style={{ backgroundImage: `url(${imageUrl})` }} 
    >
      <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-40 transition duration-300"></div>
    </div>
    <div className="absolute bottom-3 ml-4 top-0 mt-2 lg:mt-2 opacity-0 group-hover:opacity-100 transition duration-300">
      <p className="text-white text-lg md:text-xl lg:text-4xl font-semibold uppercase">{text}</p>

      <p className="text-primary -mt-2 lg:mt-1 text-sm md:text-xl lg:text-sm font-semibold uppercase">{texts}</p>
      <p className="text-white whitespace-pre-line">{description}</p>
    </div>
    {/* </Link> */}
  </div>
  </div>
 
);

interface CreatorsProps {}

const Creators: FC<CreatorsProps> = () => {
  const [search, setSearch] = useState('');

  const gridItems = [

    {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/anna.jpg",
      text:"Anna",
      texts:"Advertising",
      description:"",
      url:"#",
    }, 
    {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/naomi.jpg",
      text:"Naomi",
      texts:"Photography",
      url:"#",
  },
{
  imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/Will.png",
  text:"Will",
  texts:"Member",
  url:"#",
},
     {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/richardprofilepic.png",
      text:"Richard",
      texts:"Advertising",
      url:"#",
  },
    {
      imageUrl:"https://d15gvnltmubede.cloudfront.net/creators-pictures/thumbnail_ian.jpg",
      text:"Ian",
      texts:"Editor",
      url:"#",
  },
   
  
  ];
 /**the filter grid items based on the search query */

  const filteredGridItems = gridItems.filter((item) =>
    item.text.toLowerCase().includes(search.toLowerCase())||
    item.texts.toLowerCase().includes(search.toLowerCase())
  );


  return (
    <main className="px-10">
      

<div className="mt-5">
          <input className="w-full mt-5 lg:w-auto"
            type="text"
            placeholder="Search"
            value={search}
            onChange={(e) =>{
              setSearch(e.target.value);
            }
          }                                
          /> 
        
{/* <Link href="/kuriousstaff">
  <button className="px-10 font-semibold py-2 text-sm md:text-lg bg-primary shadow-md w-full lg:w-auto lg:ml-5 ml-0 mt-5">
     Kurious Team
  </button>
</Link> */}

    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 lg:mt-5">

                            {gridItems.map((item) => {
                                        if (item.texts.toLowerCase().includes(search.toLowerCase())||
                                            item.text.toLowerCase().includes(search.toLowerCase())) {
                                          return (
                                           
                                            <GridItem
                                              key={item.text}
                                              imageUrl={item.imageUrl}
                                              text={item.text}
                                              texts={item.texts}
                                              url={item.url}
                                              description={item.description}
                                            />
                                            
                                          );
                                        }
                                        return null; // Hide non-matching items
                                      })}
                                      
            </div>
            
    </div>
    
    <div className="w-full mt-5 ">
        <ul className="flex mb-2 md:justify-end md:gap-4 justify-between text-2xl items-center ">
          <li>
          <Link href='https://www.instagram.com/thekurious_/'>
            <BiLogoInstagram />
            </Link>
          </li>
          <li>
          <Link href='https://www.facebook.com/people/The-Kurious/100079157044792/'>
            <FaFacebookF />
            </Link>
          </li>
          <li>
          <Link href='https://twitter.com/thekurious_'>
            <FaXTwitter />
            </Link>
          </li>
          <li>
          <Link href='https://www.tiktok.com/@thekurious_'>
            <BiLogoTiktok />
            </Link>
          </li>
          <li>
          <Link href='tel:01143123659'>
            <FiPhoneCall />
            </Link>
          </li>
          <Link href="#">
            <li className="px-2 py-1 text-sm md:text-lg bg-primary rounded-lg shadow-md ">
              BOOK NOW
            </li>
          </Link>
        </ul>
      </div>

</main>
  );
};

export default Creators;
