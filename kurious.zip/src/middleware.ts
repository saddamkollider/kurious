import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
 
// This function can be marked `async` if using `await` inside
export function middleware(request: NextRequest) {

    switch (request.nextUrl.pathname) {
        case "/facilities":
            
        return NextResponse.redirect(new URL('/space', request.url))
        
        case "/memberships":   
        return NextResponse.redirect(new URL('/membership', request.url))

        case "/the-collective":   
        return NextResponse.redirect(new URL('/creators', request.url))


        case "/services-enquiry":   
        return NextResponse.redirect(new URL('/contact-us', request.url))

        case "/post-production":   
        return NextResponse.redirect(new URL('/postproduction', request.url))

        case "/service/short-feature-films":   
        return NextResponse.redirect(new URL('/services', request.url))


        case "/our-services":   
        return NextResponse.redirect(new URL('/contact-us', request.url))

        case "/make-contact":   
        return NextResponse.redirect(new URL('/contact-us', request.url))

        case "/service/brand-design":   
        return NextResponse.redirect(new URL('/branding', request.url))

        case "/marketing-social-contentx":   
        return NextResponse.redirect(new URL('/marketing-content', request.url))

        case "/service/editing":   
        return NextResponse.redirect(new URL('/postproduction', request.url))
     

        
    }  

}
 
