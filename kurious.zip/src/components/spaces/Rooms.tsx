import React from "react";
import { CarouselScroll } from "./Carousel";

export default function Rooms() {
  return (
    <section className="grid grid-cols-6 grid-rows-4 h-screen bg-[#F5F5F5]">
      <div className="border-r border-white "></div>
      <div className="border-r border-white col-span-2 relative side-bar flex flex-row  items-end">
        {" "}
        <span className="p-5 font-semibold text-lg ">STUDIO 1</span>
      </div>

      <div className="border-r border-white"></div>
      <div className="border-r bg-[#FFE025] border-white "></div>
      <div className="border-r border-white "></div>

      <div className="row-span-3 bg-[#EEEEEE] border-r border-white"></div>
      <div className="row-span-3 col-span-2 bg-[#EEEEEE] border-r border-white flex flex-row  items-center">
        <article className="px-5">
          <h2 className="font-semibold text-4xl">Display</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </p>
        </article>
      </div>
      <div className="row-span-3  border-r border-white"></div>
      <div className="row-span-3 bg-[#FFE025] border-r border-white relative">
        <div className=" h-[20rem] absolute md:min-w-[30rem] -top-28 w-full left-1/2 -translate-x-1/2">
        <CarouselScroll />
        </div>
      </div>
      <div className="row-span-3  border-r border-white"></div>
    </section>
  );
}
