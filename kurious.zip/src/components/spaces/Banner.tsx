import Image from 'next/image'
import Link from 'next/link'
import React from 'react'

export default function Banner() {
  return (
    <section className='relative w-full h-screen'>
        <img src="/assets/bg.jpeg" className='object-cover absolute' alt="background" />
      <div className="grid absolute w-full bg-[#ffffff38] z-10 h-screen grid-cols-6 grid-rows-4">
        <div className="border-r  border-b  border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r  border-b col-span-2 border-[#F5F5F5A1] w-full">
          {" "}
        </div>
        <div className="border-r border-b  border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r border-b  border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r border-b  border-[#F5F5F5A1] w-full"> </div>

        <div className="border-r    border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r   col-span-2 border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r   border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r   border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r border-[#F5F5F5A1] w-full"> </div>

        <div className="border-r  border-b  border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r  border-b col-span-2 border-[#F5F5F5A1] flex justify-start items-end w-full text-white">
          <article className="p-5">
            <h1 className="tracking-wider text-4xl font-semibold">
              PROFESSIONAL
            </h1>
            <p className="font-light text-lg">RECORDING STUDIO</p>
          </article>
        </div>
        <div className="border-r border-b  border-[#F5F5F5A1] w-full"> </div>
        <Link href="/bookings">
        <div className="border-r border-b  h-full border-[#F5F5F5A1] w-full flex justify-end items-end bg-[#FFE025] yellow-shadow">
          <article className='p-5 '>
            <h1 className='font-bold text-right text-2xl leading-3'>S1</h1>
            <span className='text-xl uppercase font-bold'>Book Now</span>
          </article>
        </div>
        </Link>
        <div className="border-r border-b  border-[#F5F5F5A1] w-full"> </div>

        <div className="border-r    border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r   col-span-2 border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r   border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r  border-[#F5F5F5A1] w-full"> </div>
        <div className="border-r   border-[#F5F5F5A1] w-full"> </div>
      </div>
    </section>
  )
}
