import React,{useState,useEffect} from "react";
import { FaForward, FaBackward } from "react-icons/fa";

interface Review {
  id: number;
  name: string;
  comment: string;
}

const reviews: Review[] = [
  {
    id: 1,
    name: "Ed Swales",
    comment:
      "There is a welcoming and mutually supportive ethos at The Kurious which makes it an ideal base for anyone working in a creative job. The variety of skills across the current membership has led me to many fulfilling collaborations and new partnerships. A great place to work!",
  },
  {
    id: 2,
    name: "Hugh Mann Adamson",
    comment:
      "What an incredible place to work, network, collaborate and create! The best thing our production company ever did was moving to The Kurious! Can't recommend it highly enough!",
  },
  {
    id: 3,
    name: "Anastasia Yules",
    comment:
      "The Kurious has some of the best post-production facilities and co-working space, and is filled with talented professionals in the industry. It's located within the city centre, which makes it so logistically convenient for the productions and/or the people who work there.",
  },
  {
    id: 4,
    name: "Ian Champion",
    comment:
      "As an actor employed by Enon Films' team at the Kurious as well as being a friend of the venue, it is a marvelous and special hub. Kurious's facilities and creatives are always buzzing with ambition and a friendly welcome. Highly recommended.",
  },
  {
    id: 5,
    name: "Gabriel Fernández-Gil",
    comment:
      "The best for hire post-production facilities in the area, literally! Amazing locations too and great co-working space filled with fantastic professionals and opportunities.",
    },
  {
    id: 6,
    name: "Charlotte Prescott",
    comment:
      "Kurious have been great at letting us hire their sound recording studio, especially at late notice. Ryan is wonderful and makes sure everything is ready for you on the day.",
    },
  {
    id: 7,
    name: "J Clark",
    comment:
      "Best working space I've been, creative relaxed environment, amazing post/design facilities and....it has a bar, ping pong table, food discount and arcade machines, what more can you want🤘.",
    },
  {
    id: 8,
    name: "Toby Watts",
    comment:
      "A great resource as a filmmaker for networking, film events and post production facilities. A huge asset to Sheffield.",
    },
  {
    id: 9,
    name: "Motunrayo Owolabi",
    comment:
      "It is always a great time working at The Kurious, you would usually feel relaxed while you are working because the people are great and the ambience is fantastic.",
    },
  {
    id: 10,
    name: " Ian Waters",
    comment:
      "A wonderful creative melting pot filled with lovely friendly people. I can't recommend it enough!",
    },
  {
    id: 11,
    name: "John-Patrick Quinn",
    comment:
      "Great collaborative workspace for creatives in the heart of Sheffield.",
    },
  {
    id: 12,
    name: "Mat Pennell",
    comment:
      "Fantastic. Helpful. Perfect",
     },
  {
    id: 13,
    name: "Bixpit Studio",
    comment:
      "A brilliant space filled with brilliant filmmakers",
    },
  // Add more reviews here
];

const CustomerReviews: React.FC = () => {
  const [currentReviewIndex, setCurrentReviewIndex] = React.useState(0);

  const nextReview = () => {
    setCurrentReviewIndex((prevIndex) =>
      prevIndex === reviews.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevReview = () => {
    setCurrentReviewIndex((prevIndex) =>
      prevIndex === 0 ? reviews.length - 1 : prevIndex - 1
    );
  };

  useEffect(() => {
    const interval = setInterval(nextReview, 3000); // Change the interval duration as needed
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-full lg:max-h-96 p-4">

      <div className=" lg:mt-5 mt-0 border-gray-200 p-4 rounded-lg">
        <p className="lg:text-lg md:text-[1rem] text-[0.6rem]">
          {reviews[currentReviewIndex].comment}
        </p>
        <p className="text-right text-sm mt-2 font-semibold">
          - {reviews[currentReviewIndex].name}
        </p>
      </div>

      <div className="w-full">
        <button
          onClick={prevReview}
          className="transform -translate-y-1/2 p-2 rounded-full bg-primary shadow-md hover:shadow-lg cursor-pointer z-20"
        >
          <FaBackward />
        </button>
        <button
          onClick={nextReview}
          className="transform -translate-y-1/2 p-2 rounded-full bg-primary  shadow-md hover:shadow-lg cursor-pointer z-20"
        >
          <FaForward />
        </button>
      </div>
    </div>
  );
};

export default CustomerReviews;
