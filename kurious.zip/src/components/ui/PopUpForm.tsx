import React, { useState } from 'react';
import { Button, Modal } from 'flowbite-react';

function PopUpForm() {
  const [openModal, setOpenModal] = useState(false);

  return (
    <>
      <Button onClick={() => setOpenModal(true)} className="px-0 py-0 text-black text-5xl md:text-lg bg-primary rounded-lg shadow-md hover:bg-primary focus:ring-primary"
      style={{ color: 'black', background:'#FFE025' }}>
        Book NOW
      </Button>
      <Modal show={openModal} onClose={() => setOpenModal(false)}>
        <Modal.Body>
          <div className="space-y-6">
            <iframe
              src="https://www.cognitoforms.com/f/TBvlivnYu0qXj9F9C55Oqg/129"
              style={{ border: '0', width: '100%' }}
              height="600"
              title="Cognito Form"
            ></iframe>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button
            className='absolute px-2 bg-primary right right-5 hover:bg-primary focus:ring-white'
            style={{ color: 'black', background:'#FFE025', border: '2px solid white' }} // Change the color to your desired color
            onClick={() => setOpenModal(false)}
          >
{/* focus:outline-none text-white border border-transparent enabled:hover:bg-yellow-300  focus:ring-white dark:bg-yellow-300 dark:enabled:hover:bg-yellow-300 dark:focus:ring-yellow-300 */}

            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default PopUpForm;

