'use client';
import { Button, Modal, Select } from 'flowbite-react';
import { FC, useEffect, useState } from 'react';


interface GalleryPopUpProps {
modalState:{
    openModal: boolean,
    setOpenModal: React.Dispatch<React.SetStateAction<boolean>>;
},
imageList:React.ReactElement[]
}

 const GalleryPopUp:FC<GalleryPopUpProps>=({modalState,imageList})=> {

    useEffect(()=>{
console.log(window.innerWidth)
    },[])

  return (
    <>
      
      <Modal
        show={modalState.openModal}
        position="center"
        size="7xl"
        onClose={() => modalState.setOpenModal(false)}
      >
        <Modal.Header></Modal.Header>
        <Modal.Body>
            <div className='grid max-h-[42rem] mb-10 p-5 lg:grid-cols-3 md:grid-cols-2 gap-5'>
                {imageList.map((val,key)=>(
                    <div className='w-fit h-72 md:h-[21rem]' key={`gallery-${key}`}>
                       {val}
                    </div>
                ))}
            </div>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </>
  );
}

export default GalleryPopUp
