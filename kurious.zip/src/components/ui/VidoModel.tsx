
import React from 'react';
import { IoCloseSharp } from "react-icons/io5";
interface VideoModalProps {
  source: string;
  onClose: () => void;
}

const VideoModal: React.FC<VideoModalProps> = ({ source, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
     
      <div className="bg-white relative p-4 rounded-lg shadow-lg">
      <button onClick={onClose} className="text-Black hover:bg-gray-100 shadow-lg rounded-full p-2 absolute top-0 right-0 cursor-pointer">
          <IoCloseSharp />
        </button>
        <video controls autoPlay className="w-[59vh] mt-5 h-[70vh] lg:w-full lg:h-[70vh]">
          <source src={source} type="video/mp4" />
        </video>
     
      </div>
    </div>
  );
};

export default VideoModal;
