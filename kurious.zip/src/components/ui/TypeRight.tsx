"use client"
import type { FC } from 'react';
import Typewriter from "typewriter-effect"
interface TypewriteProps {
  wordsList:string[]
}

const Typewrite: FC<TypewriteProps> = ({wordsList}) => {
  return (
    <Typewriter
    options={{
      autoStart:true,
      loop: true,
      delay:50,
      strings:wordsList
    }} 
    />
  );
}

export default Typewrite;
