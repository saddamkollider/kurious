
// import React, { useState } from 'react';
// import emailjs from '@emailjs/browser';
import React, { useState, useRef } from 'react';
import emailjs from '@emailjs/browser';

interface ContactFormData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  about: string;
  spaceOptions?: string[];
  serviceOptions?: string[];
  membershipOptions?: string[];
  allfilmOptions?: string[];
  message: string;
  [key: string]: any; // Index signature allowing indexing with a string
}

interface ContactFormProps {
  onSubmit: (data: ContactFormData) => void;
}

const ContactForm: React.FC<ContactFormProps> = ({ onSubmit }) => {
  const form = useRef<HTMLFormElement>(null);
  const [submissionSuccess, setSubmissionSuccess] = useState<boolean>(false);
  
  const sendEmail = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (form.current) {
      emailjs.sendForm('service_5sun0xs', 'template_zyi7qvl', form.current, {
        publicKey: 'KBl9E-m8PuOGFyCBX',
      })
      .then(() => {
        console.log('SUCCESS!');
        setSubmissionSuccess(true);
        setFormData({
          firstName: '',
          lastName: '',
          email: '',
          phoneNumber: '',
          about: '',
          spaceOptions: [] as string[],
          serviceOptions: [] as string[],
          membershipOptions: [] as string[],
          allfilmOptions: [] as string[],
          message: '',
        });
        setErrors({});
      })
      .catch((error) => {
        console.log('FAILED...', error.text);
      });
    }
  };

  const [formData, setFormData] = useState<ContactFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    about: '',
    spaceOptions: [] as string[],
    serviceOptions: [] as string[],
    membershipOptions: [] as string[],
    allfilmOptions: [] as string[],
    message: '',
  });

  const [errors, setErrors] = useState<Partial<ContactFormData>>({});
  const [showSpaceOptions, setShowSpaceOptions] = useState<boolean>(false);
  const [showServiceOptions, setShowServiceOptions] = useState<boolean>(false);
  const [showMembershipOptions, setShowMembershipOptions] = useState<boolean>(false);
  const [showAllfilmOptions, setShowAllfilmOptions] = useState<boolean>(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: '' });

    if (name === 'about') {
      setShowSpaceOptions(value === 'Space');
      setShowServiceOptions(value === 'Service');
      setShowMembershipOptions(value === 'Membership');
      setShowAllfilmOptions(value === 'Allfilm');
    }
  };

  const handleOptionChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    optionsField: keyof Omit<ContactFormData, 'firstName' | 'lastName' | 'email' | 'phoneNumber' | 'message'>
  ) => {
    const { value, checked } = e.target;
    setFormData((prevData) => {
      const updatedOptions = (prevData[optionsField] as string[]) || [];
      if (checked) {
        return { ...prevData, [optionsField]: [...updatedOptions, value] };
      } else {
        return { ...prevData, [optionsField]: updatedOptions.filter(option => option !== value) };
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formErrors: Partial<ContactFormData> = {};
    if (!formData.firstName) {
      formErrors.firstName = 'First Name is required';
    }
    if (!formData.lastName) {
      formErrors.lastName = 'Last Name is required';
    }
    if (!formData.email) {
      formErrors.email = 'Email is required';
    } else if (!isValidEmail(formData.email)) {
      formErrors.email = 'Invalid email format';
    }
    if (!formData.phoneNumber) {
      formErrors.phoneNumber = 'Phone Number is required';
    }
    if (!formData.about) {
      formErrors.about = 'Please select an option';
    }
    if (formData.about === 'Space' && !formData.spaceOptions?.length) {
      formErrors.spaceOptions = ['Please select at least one option']; // Array containing the error message
    }
    if (formData.about === 'Service' && !formData.serviceOptions?.length) {
      formErrors.serviceOptions = ['Please select at least one option']; // Array containing the error message
    }
    if (formData.about === 'Membership' && !formData.membershipOptions?.length) {
      formErrors.membershipOptions = ['Please select at least one option'];
    }
    if (formData.about === 'Allfilm' && !formData.allfilmOptions?.length) {
      formErrors.allfilmOptions = ['Please select at least one option'];
    }
    if (!formData.message) {
      formErrors.message = 'Message is required';
    }
    setErrors(formErrors);
    if (Object.keys(formErrors).length === 0) {
      onSubmit(formData);
    }
  };

  const isValidEmail = (email: string) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  return (
    <form ref={form} onSubmit={sendEmail} className="grid grid-cols-2 gap-4">
      <div>
        <label htmlFor="firstName" className="block font-bold text-sm ">
          First Name:<span className='text-red-500'>*</span>
        </label>
        <input
          type="text"
          id="firstName"
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
          className={`border rounded-md px-2 py-1 w-full text-sm ${errors.firstName && 'border-red-500'}`}
          required
        />
        {errors.firstName && <p className="text-red-500">{errors.firstName}</p>}
      </div>
      {/* Last Name field */}
      <div>
        <label htmlFor="lastName" className="block font-bold text-sm">
          Last Name:<span className='text-red-500'>*</span>
        </label>
        <input
          type="text"
          id="lastName"
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
          className={`border rounded-md px-2 py-1 w-full text-sm ${errors.lastName && 'border-red-500'}`}
          required
        />
        {errors.lastName && <p className="text-red-500">{errors.lastName}</p>}
      </div>
      {/* Email field */}
      <div>
        <label htmlFor="email" className="block font-bold text-sm">
          Email: <span className='text-red-500'>*</span>
        </label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          className={`border rounded-md px-2 py-1 w-full text-sm ${errors.email && 'border-red-500'}`}
          required
        />
        {errors.email && <p className="text-red-500">{errors.email}</p>}
      </div>
      {/* Phone Number field */}
      <div>
        <label htmlFor="phoneNumber" className="block font-bold text-sm">
          Phone Number:<span className='text-red-500'>*</span>
        </label>
        <input
          type="tel"
          id="phoneNumber"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
          className={`border rounded-md px-2 py-1 w-full text-sm ${errors.phoneNumber && 'border-red-500'}`}
          required
        />
        {errors.phoneNumber && <p className="text-red-500">{errors.phoneNumber}</p>}
      </div>
      {/* About Kurious dropdown */}
      <div className="col-span-2">
        <label htmlFor="about" className="block font-bold text-sm">
          About Kurious:<span className='text-red-500'>*</span>
        </label>
        <select
          id="about"
          name="about"
          value={formData.about}
          onChange={handleChange}
          className={`border rounded-md px-2 py-1 w-full text-sm ${errors.about && 'border-red-500'}`}
          required
        >
          <option value="">Select an option</option>
          <option value="Space">Space</option>
          <option value="Service">Service</option>
          <option value="Membership">Membership</option>
          <option value="Allfilm">Allfilm</option>
        </select>
        {errors.about && <p className="text-red-500">{errors.about}</p>}
      </div>
      {/* Dynamic options */}
      {/* Space options */}
      {showSpaceOptions && (
        <div className="col-span-2">
          <label className="block font-bold text-sm">Space Options:</label>
          <div>
            <label htmlFor="soundSuite" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="soundSuite"
                name="soundSuite"
                value="Sound Suite"
                onChange={(e) => handleOptionChange(e, 'spaceOptions')}
                className="mr-2"
              />
              Sound Suite
            </label>
            <label htmlFor="editSuite" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="editSuite"
                name="editSuite"
                value="Edit Suite"
                onChange={(e) => handleOptionChange(e, 'spaceOptions')}
                className="mr-2"
              />
              Edit Suite
            </label>
            {/* Include more options similarly */}

            <label htmlFor="productionSpace" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="productionSpace"
                name="productionSpace"
                value="Production Space"
                onChange={e => handleOptionChange(e, 'serviceOptions')}
                className="mr-2"
              />
              Production Space
            </label>
         
            <label htmlFor="eventSpace" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="eventSpace"
                name="eventSpace"
                value="Event Space"
                onChange={e => handleOptionChange(e, 'serviceOptions')}
                className="mr-2"
              />
              Event Space
            </label>
            <label htmlFor="other" className="inline-block text-sm">
              <input
                type="checkbox"
                id="other"
                name="other"
                value="Other"
                onChange={e => handleOptionChange(e, 'serviceOptions')}
                className="mr-2"
              />
              Other
            </label>
          </div>
          {errors.spaceOptions && <p className="text-red-500">{errors.spaceOptions}</p>}
        </div>
      )}
      {/* Service options */}
      {showServiceOptions && (
        <div className="col-span-2">
          <label className="block font-bold text-sm">Service Options:</label>
          <div>
            <label htmlFor="filmProduction" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="filmProduction"
                name="filmProduction"
                value="Film Production"
                onChange={(e) => handleOptionChange(e, 'serviceOptions')}
                className="mr-2"
              />
              Film Production
            </label>
            {/* Include more options similarly */}
            <label htmlFor="podcastingAudio" className="inline-block mr-4 text-sm">
             <input
                type="checkbox"
                id="podcastingAudio"
                name="podcastingAudio"
                value="Podcasting / Audio"
                onChange={e => handleOptionChange(e, 'serviceOptions')}
                className="mr-2"
              />
              Podcasting / Audio
            </label>
            <label htmlFor="marketingContent" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="marketingContent"
                name="marketingContent"
                value="Marketing / Content"
                onChange={e => handleOptionChange(e, 'serviceOptions')}
                className="mr-2"
              />
              Marketing / Content
            </label>
            <label htmlFor="marketingContent" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="others"
                name="others"
                value="others"
                onChange={e => handleOptionChange(e, 'serviceOptions')}
                className="mr-2"
              />
              Other
            </label>
                </div>
          {errors.serviceOptions && <p className="text-red-500">{errors.serviceOptions}</p>}
        </div>
      )}
      {/* Membership options */}
      {showMembershipOptions && (
        <div className="col-span-2">
          <label className="block font-bold text-sm">Membership Options:</label>
          <div>
            <label htmlFor="remoteMembership" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="remoteMembership"
                name="remoteMembership"
                value="Remote Membership"
                onChange={(e) => handleOptionChange(e, 'membershipOptions')}
                className="mr-2"
              />
              Remote Membership
            </label>
            <label htmlFor="remoteMembership" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="onlineMembership"
                name="onlineMembership"
                value="Online Membership"
                onChange={(e) => handleOptionChange(e, 'membershipOptions')}
                className="mr-2"
              />
              Online Membership
            </label>
            <label htmlFor="remoteMembership" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="officeSpace"
                name="officeSpace"
                value="officeSpace"
                onChange={(e) => handleOptionChange(e, 'membershipOptions')}
                className="mr-2"
              />
              Office Space/ Meeting Room
            </label>
            <label htmlFor="remoteMembership" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="others"
                name="others"
                value="others"
                onChange={(e) => handleOptionChange(e, 'membershipOptions')}
                className="mr-2"
              />
              Others
            </label>

            {/* Include more options similarly */}
          </div>
          {errors.membershipOptions && <p className="text-red-500">{errors.membershipOptions}</p>}
        </div>
      )}
      {/* Allfilm options */}
      {showAllfilmOptions && (
        <div className="col-span-2">
          <label className="block font-bold text-sm">Allfilm Options:</label>
          <div>
            <label htmlFor="submitAFilm" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="submitAFilm"
                name="submitAFilm"
                value="Submit a film"
                onChange={(e) => handleOptionChange(e, 'allfilmOptions')}
                className="mr-2"
              />
              Submit a film
            </label>
            <label htmlFor="submitAFilm" className="inline-block mr-4 text-sm">
              <input
                type="checkbox"
                id="others"
                name="others"
                value="others"
                onChange={(e) => handleOptionChange(e, 'allfilmOptions')}
                className="mr-2"
              />
              Others
            </label>
            {/* Include more options similarly */}
          </div>
          {errors.allfilmOptions && <p className="text-red-500">{errors.allfilmOptions}</p>}
        </div>
      )}
      {/* Message field */}
      <div className="col-span-2">
        <label htmlFor="message" className="block font-bold text-sm">
          Message:<span className='text-red-500'>*</span>
        </label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          className={`border rounded-md px-3 py-2 w-full ${errors.message && 'border-red-500'}`}
          required
        />
        {errors.message && <p className="text-red-500">{errors.message}</p>}
      </div>
      {/* Submit button */}
      <button type="submit" className="col-span-2 bg-primary  text-black py-2 px-4 rounded-md">
        Submit
      </button>
      {submissionSuccess && (
        <div className="col-span-2 text-green-500">Form submitted successfully!</div>
      )}
    </form>
  );
};

export default ContactForm;
