import Image from 'next/image';
import type { FC } from 'react';

interface ProductBannerProps {
    spanPosition:string;
    spanText:string
}

const ProductBanner: FC<ProductBannerProps> = ({spanPosition,spanText}) => {
    return (
        <section className='relative h-96 w-full'>
        <div className='bg-black/60 w-full h-full absolute z-[1]'></div>
        <img src="/assets/pdDemo.jpeg"  alt="product demo" className='h-96 w-full absolute object-cover'   />
        <article className='absolute z-[2] bottom-0 left-5 text-[5rem] font-bold  text-white'>
            <h2>SOUND SUITES</h2>
        </article>
        <span className={`absolute outline-text z-[2] rotate-45 ${spanPosition}`}>{spanText}</span>
    </section>
    );
}

export default ProductBanner;
