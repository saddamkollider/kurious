import Link from 'next/link'
import React from 'react'
import { BiLogoInstagram, BiLogoTiktok } from 'react-icons/bi'
import { FaFacebookF } from 'react-icons/fa'
import { FaXTwitter } from 'react-icons/fa6'
import { FiPhoneCall } from 'react-icons/fi'
import PopUpForm from '../PopUpForm'

export default function SocialLink() {
  return (
    <div className="w-full mt-5 mb-5 ">
        <ul className="flex mb-2 md:justify-end md:gap-4 justify-between text-2xl items-center ">
          <li>
          <Link href='https://www.instagram.com/thekurious_/'>
            <BiLogoInstagram />
            </Link>
          </li>
          <li>
          <Link href='https://www.facebook.com/people/The-Kurious/100079157044792/'>
            <FaFacebookF />
            </Link>
          </li>
          <li>
          <Link href='https://twitter.com/thekurious_'>
            <FaXTwitter />
            </Link>
          </li>
          <li>
          <Link href='https://www.tiktok.com/@thekurious_'>
            <BiLogoTiktok />
            </Link>
          </li>
          <li>
          <Link href='tel:01143123659'>
            <FiPhoneCall />
            </Link>
          </li>
          {/* <li>
          <PopUpForm/>
          </li> */}
        </ul>
      </div>
  )
}
