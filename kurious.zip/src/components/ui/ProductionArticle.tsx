import type { FC } from 'react';

interface ProductArticleProps {
    heading:string,
    paragraph:string
}

const ProductArticle: FC<ProductArticleProps> = ({heading,paragraph}) => {
    return (
        <article className="max-w-4xl  tracking-wide mx-auto my-10">
        <p className="lg:text-[1.8rem] font-semibold text-xl pb-3 text-center"> {heading}</p>
       <p className="max-w-4xl tracking-wide mx-auto  text-center">{paragraph}</p>
         </article>
    );
}

export default ProductArticle;
