// import React, { useState } from 'react';

// interface ImageInfo {
//   imageUrl: string;
//   link: string;
// }

// interface SpacegalleryProps {
//   onClose: () => void;
//   images: ImageInfo[]; // Pass an array of objects with imageUrl and link properties
//   width: string; // Custom width for the pop-up window
//   height: string; // Custom height for the pop-up window
// }

// const PopUp: React.FC<SpacegalleryProps> = ({ onClose, images, width, height }) => {
//   return (
//     <div className="flex item-center justify-center bg-black bg-opacity-75">
//       <div style={{ width, height }} className="bg-white rounded-lg overflow-hidden">
//         <button
//           className="relative right-2 text-[1rem] lg:text-[1.5rem] text-black hover:text-gray-700"
//           onClick={onClose}
//         >
//           Close
//         </button>
//         <div className="grid lg:grid-cols-4 grid-cols-2 gap-3">
//           {images.map((imageInfo, index) => (
//             <a key={index} href={imageInfo.link} target="_blank" rel="noopener noreferrer">
//               <div className="overflow-hidden rounded-md aspect-w-1 aspect-h-1">
//                 <img
//                   src={imageInfo.imageUrl}
//                   alt={`Image ${index + 1}`}
//                   className=" object-cover"
//                 />
//               </div>
//             </a>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// };

// const App: React.FC = () => {
//   const [isPopUpOpen, setIsPopUpOpen] = useState(false);
//   const userImages: ImageInfo[] = [
//     // Add your own image URLs and corresponding links here
//     {
//       imageUrl: '/assets/Space-soundImage/space1.jpg',
//       link: 'https://example.com/link1',
//     },
//     {
//       imageUrl: '/assets/Space-soundImage/space2.jpg',
//       link: 'https://example.com/link1',
//     },
//     {
//       imageUrl: '/assets/Space-soundImage/space3.jpg',
//       link: 'https://example.com/link1',
//     },
//     {
//       imageUrl: '/assets/Space-soundImage/space4.jpg',
//       link: 'https://example.com/link1',
//     },
//     {
//       imageUrl: '/assets/Space-soundImage/space5.jpg',
//       link: 'https://example.com/link1',
//     },
//     {
//       imageUrl: '/assets/Space-soundImage/space6.jpg',
//       link: 'https://example.com/link1',
//     },
//     {
//       imageUrl: '/assets/Space-soundImage/space7.jpg',
//       link: 'https://example.com/link1',
//     },
//     {
//       imageUrl: '/assets/Space-soundImage/space8.jpg',
//       link: 'https://example.com/link1',
//     },
   
    
//     // ... add more image URLs and links
//   ];

//   const popUpWidth = ''; // Adjust as needed
//   const popUpHeight = ''; // Adjust as needed

//   return (
//     <div className="uppercase absolute bottom-5 lg:mt-3 right-4 lg:right-8 md:left-5 text-white  text-1xl md:text-6xl lg:text-2xl font-bold text-right">
//       <button onClick={() => setIsPopUpOpen(true)}>Click to see more</button>
//       {isPopUpOpen && (
//         <PopUp
//           onClose={() => setIsPopUpOpen(false)}
//           images={userImages}
//           width={popUpWidth}
//           height={popUpHeight}
//         />
//       )}
//     </div>
//   );
// };

// export default App;

import React, { useState } from 'react';

interface ImageInfo {
  imageUrl: string;
  link: string;
}

interface SpacegalleryProps {
  onClose: () => void;
  images: ImageInfo[]; // Pass an array of objects with imageUrl and link properties
  width: string; // Custom width for the pop-up window
  height: string; // Custom height for the pop-up window
}

const PopUp: React.FC<SpacegalleryProps> = ({ onClose, images, width, height }) => {
  return (
    <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black bg-opacity-75">
      <div style={{ width, height }} className="bg-white rounded-lg overflow-hidden relative">
        <button
          className="absolute top-2 right-2 text-[1rem] lg:text-[1.5rem] text-black hover:text-gray-700"
          onClick={onClose}
        >
          Close
        </button>
        <div className='overflow-y-auto h-full'>
        <div className="grid lg:grid-cols-3  h-full grid-cols-1 gap-3 lg:pt-10 lg:pl-4 lg:pr-4 pt-8 pl-4 pr-4">
          {images.map((imageInfo, index) => (
            <a key={index} href={imageInfo.link} target="_blank" rel="noopener noreferrer">
              <div className="overflow-hidden rounded-md aspect-w-1 aspect-h-1">
                <img
                  src={imageInfo.imageUrl}
                  alt={`Image ${index + 1}`}
                  className="object-cover h-60"
                />
              </div>
            </a>
          ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [isPopUpOpen, setIsPopUpOpen] = useState(false);
  const userImages: ImageInfo[] = [
    // Add your own image URLs and corresponding links here
    {
           imageUrl: '/assets/Space-soundImage/space1.jpg',
             link: 'https://example.com/link1',
           },
         {
           imageUrl: '/assets/Space-soundImage/space2.jpg',
           link: 'https://example.com/link1',
         },
         {
           imageUrl: '/assets/Space-soundImage/space3.jpg',
           link: 'https://example.com/link1',
         },
         {
            imageUrl: '/assets/Space-soundImage/space4.jpg',
                 link: 'https://example.com/link1',
               },

               {
                      imageUrl: '/assets/Space-soundImage/space7.jpg',
                      link: 'https://example.com/link1',
                    },
                    {
                      imageUrl: '/assets/Space-soundImage/space8.jpg',
                      link: 'https://example.com/link1',
                    },
                   
  ];

  const popUpWidth = '80%'; // Adjust as needed
  const popUpHeight = '80%'; // Adjust as needed

  return (
    <div className="uppercase absolute bottom-5 right-4 lg:right-8 md:left-5 text-white text-1xl md:text-6xl lg:text-2xl font-bold text-right">
      <button onClick={() => setIsPopUpOpen(true)}>Click to see more</button>
      {isPopUpOpen && (
        <PopUp
          onClose={() => setIsPopUpOpen(false)}
          images={userImages}
          width={popUpWidth}
          height={popUpHeight}
        />
      )}
    </div>
  );
};

export default App;
