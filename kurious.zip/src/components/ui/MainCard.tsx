import Image from "next/image";
import Link from "next/link";
import '@/components/externalcss/style.css';
import PopUpForm from '@/components/ui/PopUpForm';
import type { FC } from "react";

interface MainCardProps {
  children: React.ReactNode;
}

const MainCard: FC<MainCardProps> = ({ children }) => {
  return (
    <section className="mt-5">
      <div className="parent-div md:h-[85vh] h-[65vh] relative w-full">{children}</div>
     
    </section>  
  );
  
};

export default MainCard;
