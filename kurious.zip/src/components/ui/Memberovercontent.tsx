import React from 'react';

interface MemberovercontentProps {
  items: string[];
}

const Memberovercontent: React.FC<MemberovercontentProps> = ({ items }) => {
  return (
    <ul className="list-disc">
      {items.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  );
};

export default Memberovercontent;
