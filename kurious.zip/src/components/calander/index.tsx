"use client"
import React, { useState, useEffect } from 'react';
import moment from 'moment';

interface CalendarDay {
  date: moment.Moment;
  isSelected: boolean;
  isPast: boolean; 
}

const MonthlyCalendar: React.FC = () => {
  const [currentMonth, setCurrentMonth] = useState(moment());
  const [calendar, setCalendar] = useState<CalendarDay[][]>([]);

  useEffect(() => {
    const daysInMonth = currentMonth.daysInMonth();
    const firstDay = moment(currentMonth).startOf('month').startOf('week');
    const lastDay = moment(currentMonth).endOf('month').endOf('week');

    const calendarData: CalendarDay[][] = [];
    let currentDay = firstDay.clone();

    while (currentDay.isBefore(lastDay)) {
      const week: CalendarDay[] = [];
      for (let i = 0; i < 7; i++) {
        const isPast = currentDay.isBefore(moment(), 'day'); // Check if the date is in the past
        week.push({
          date: currentDay.clone(),
          isSelected: currentDay.isSame(moment(), 'day'),
          isPast
        });
        currentDay.add(1, 'day');
      }
      calendarData.push(week);
    }

    setCalendar(calendarData);
  }, [currentMonth]);

  const prevMonth = () => {
    setCurrentMonth(currentMonth.clone().subtract(1, 'month'));
  };

  const nextMonth = () => {
    setCurrentMonth(currentMonth.clone().add(1, 'month'));
  };

  return (
    <>
      <div className=''>
        <div className='flex gap-5 mb-5'>
        <span className='text-5xl font-extrabold text-blue-gray-900'>{currentMonth.format('MMM YYYY')}</span>
        <g>
        <svg width={96} height={43} viewBox="0 0 96 43" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path onClick={nextMonth}  d="M75.7571 0L71 5.0525L86.4521 21.5L71 37.9475L75.7571 43L96 21.5L75.7571 0Z" fill="#353E46" />
  <path onClick={prevMonth} d="M28 5.0525L22.6721 0L0 21.5L22.6721 43L28 37.9475L10.6937 21.5L28 5.0525Z" fill="#353E46" />
  <path d="M47 14C43.129 14 40 17.129 40 21C40 24.871 43.129 28 47 28C50.871 28 54 24.871 54 21C54 17.129 50.871 14 47 14Z" fill="#353E46" />
</svg>
</g>
        </div>
        <p className='mb-6'>Select a date that you want to book</p>
      

      </div>
    <div className="grid grid-cols-7 gap-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
          <div key={index} className=" font-semibold text-blue-gray-800">
            {day}
          </div>
        ))}
        {calendar.map((week, weekIndex) => (
          week.map((day) => (
            <div
              key={day.date.format('DD')}
              className={`p-2  border-t-2 h-[15rem] ${
                day.isSelected ? 'bg-blue-500 text-white' : day.isPast ? 'bg-gray-200' : 'bg-[#f5f5f5]/50'
              }`}
            >
              {day.date.format('D')}
            </div>
          ))
        ))}
      </div>
     </> 
  );
};

export default MonthlyCalendar;
