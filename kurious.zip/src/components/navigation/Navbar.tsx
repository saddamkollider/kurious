'use client';
import Link from 'next/link';

import { Navbar } from 'flowbite-react';

export default function KuriousNavbar() {
  return (
    <Navbar fluid rounded className='mt-2 -mb-3 '>
      <Navbar.Brand  href="/">
        <img src="/assets/logo.png" className="mr-3 h-6 sm:h-9 ml-5" alt="The-kurious Logo" />
       
      </Navbar.Brand>
      <Navbar.Toggle />
      <Navbar.Collapse className='ml-6 lg:mr-3 md:hover:text-primary' >

      
        <Navbar.Link className='md:hover:text-[#FFE025] lg:hover:text-[#FFE025] hover:text-[#FFE025]' href="/">  Home</Navbar.Link>
        <Navbar.Link className='md:hover:text-[#FFE025] lg:hover:text-[#FFE025] hover:text-[#FFE025]' href="/creators">Creators</Navbar.Link>
        <Navbar.Link className='md:hover:text-[#FFE025]  lg:hover:text-[#FFE025] hover:text-[#FFE025]' href="/space">Spaces</Navbar.Link>
        <Navbar.Link className='md:hover:text-[#FFE025] lg:hover:text-[#FFE025] hover:text-[#FFE025]' href="/all">All </Navbar.Link>
        <Navbar.Link className='md:hover:text-[#FFE025] lg:hover:text-[#FFE025] hover:text-[#FFE025]' href="/services">Service</Navbar.Link>
        <Navbar.Link className='md:hover:text-[#FFE025] lg:hover:text-[#FFE025] hover:text-[#FFE025]' href="/membership">Membership</Navbar.Link>
        <Navbar.Link className='md:hover:text-[#FFE025] lg:hover:text-[#FFE025] hover:text-[#FFE025]' href="/contact-us">Contact Us</Navbar.Link>

      </Navbar.Collapse>
    </Navbar>
  )
}


