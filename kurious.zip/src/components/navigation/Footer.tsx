'use client';

import { Footer } from 'flowbite-react';
import { BsDribbble, BsFacebook, BsGithub, BsInstagram, BsTwitter } from 'react-icons/bs';

export default function KuriousFooter() {
  return (
    <Footer container>
      <div className="w-full">
        <div className="grid justify-between ml-4 sm:flex sm:justify-between md:flex md:grid-cols-1">
          <div>
            <Footer.Brand
              alt="The-kuriousLogo"
              href=""
              name="The-Kurious Logo"
              src="/assets/logo.png"
            />
          </div>
          <div className="grid grid-cols-1 lg:text-xs  gap-2 mt-4 mr-5 text-sm  lg:mr-8 xl:mr-10 sm:mt-4 sm:grid-cols-3 sm:gap-2">
  <div>
    <Footer.Title title="About Us" className='mt-5' />
    <Footer.LinkGroup col className='-mt-4'>
      <Footer.Link href="/space">Spaces</Footer.Link>
      <Footer.Link href="/services">Service</Footer.Link>
    </Footer.LinkGroup>
  </div>
  <div>
    <Footer.Title title="Follow us" className='mt-5' />
    <Footer.LinkGroup col className='-mt-4'>
      <Footer.Link href="/membership">Membership</Footer.Link>
      <Footer.Link href="/creators">Creators</Footer.Link>
    </Footer.LinkGroup>
  </div>
  <div>
    <Footer.Title title="Legal" className='mt-5' />
    <Footer.LinkGroup col className='-mt-4'>
      <Footer.Link href="/privacy">Privacy Policy</Footer.Link>
      <Footer.Link href="/termsandconditions">Terms & Conditions</Footer.Link>
    </Footer.LinkGroup>
  </div>
</div>

        </div>
        <Footer.Divider />
        <div className="w-full items-center sm:flex sm:items-center sm:justify-between">
          <Footer.Copyright
            by="The-Kurious.All Rights Reserved.™"
            href="#"
            year={2023}
          />
          {/* <div className="mt-4 flex space-x-6 sm:mt-0 sm:justify-center">
            <Footer.Icon
              href="#"
              icon={BsFacebook}
            />
            <Footer.Icon
              href="#"
              icon={BsInstagram}
            />
            <Footer.Icon
              href="#"
              icon={BsTwitter}
            />
            <Footer.Icon
              href="#"
              icon={BsGithub}
            />
            <Footer.Icon
              href="#"
              icon={BsDribbble}
            />
          </div> */}
           <div className="">
          <a href="/contact-us"><div className="px-2 py-1 mr-5 text-sm text-center w-28 md:text-lg bg-primary rounded-lg shadow-md ">Contact Us</div></a>
          </div>
        </div>
      </div>
    </Footer>
  )
}


