import React from 'react';
interface GridItem {
  imageUrl: string;
  text: string;
}

const CompanyLogos: React.FC = () => {
  // Sample data for images and text
  const gridData: GridItem[] = [

    {
          imageUrl: '/logo/calendar.png',
          text: 'Communal Work Spaces',
        },
        {
          imageUrl: '/logo/clock.png',
          text: '8am - 6pm weekday access',
        },
        {
          imageUrl: '/logo/couch.png',
          text: 'Breakout Space',
        },
        {
          imageUrl: '/logo/cuply.png',
          text: 'Kitchen facilities',
        },{
          imageUrl: '/logo/elevator.png',
          text: 'Service lift access',
        },{
          imageUrl: '/logo/headphones.png',
          text: 'On-site technical support',
        },
        {
          imageUrl: '/logo/calendar.png',
          text: 'Event Spaces',
        },
        {
          imageUrl: '/logo/lamp-decor.png',
          text: 'Serviced Building',
        },{
          imageUrl: '/logo/lock-phone.png',
          text: 'Secure Key Access',
        },{
          imageUrl: '/logo/mail.png',
          text: 'Post + Package Handling',
        },{
          imageUrl: '/logo/meeting.png',
          text: 'Meeting Spaces',
        },{
          imageUrl: '/logo/networking.png',
          text: 'Networking Events and Weekly Movie Night',
        },{
          imageUrl: '/logo/table-soccer.png',
          text: 'Invite Only Social Events',
        },{
          imageUrl: '/logo/wifi.png',
          text: 'Free Superfast WIFI',
        },
        {
          imageUrl: '/logo/Train.png',
          text: '10mins walk from the train station',
        },
        {
          imageUrl: '/logo/Secure_bike2.png',
          text: 'Secure Bike Storage',
        },
        {
          imageUrl:'/logo/funds.jpeg',
          text:'Access to funding',
        },
        {
          imageUrl:'/logo/profile.png',
          text:' Profile on Kurious website',
        },
        {
          imageUrl:'/logo/revenu.jpeg',
          text:'Revenue from projects and social media content',
        },
        
    // Add more data as needed
  
  ];


  return (
    <div className=" text-xs grid grid-cols-3 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
      {gridData.map((item, index) => (
        <div
          key={index}
          className="text-center relative group py-4 px-4"
        >
          <div className="mb-2"> {/* Wrapper for the text */}
            <img
              src={item.imageUrl}
              alt={`Image ${index + 1}`}
              className="mx-auto w-70 h-70 transform-gpu hover:-translate-y-2 transition-transform"
            />
          </div>
          <p>{item.text}</p>
        </div>
      ))}
    </div>
  );
};

export default CompanyLogos;
